import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['class'],
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        sans: ['var(--font-sans)', 'system-ui'],
      },
      colors: {
        // Telegram theme passthrough
        tg: {
          bg: 'var(--tg-bg)',
          text: 'var(--tg-text)',
          hint: 'var(--tg-hint)',
          link: 'var(--tg-link)',
          button: 'var(--tg-button)',
          buttonText: 'var(--tg-button-text)',
          secondary: 'var(--tg-secondary-bg)',
        },
        brand: {
          50:  '#fff8ed',
          100: '#ffefd4',
          200: '#ffdba8',
          300: '#ffbf70',
          400: '#ff9a38',
          500: '#ff7a14',
          600: '#f05e08',
          700: '#c74608',
          800: '#9d370f',
          900: '#7f2f10',
        },
      },
      borderRadius: {
        xl: 'calc(var(--radius) + 4px)',
        '2xl': 'calc(var(--radius) + 8px)',
        '3xl': 'calc(var(--radius) + 16px)',
      },
      boxShadow: {
        'soft': '0 4px 24px -8px rgba(15,23,42,0.08), 0 2px 6px -2px rgba(15,23,42,0.04)',
        'soft-lg': '0 12px 48px -12px rgba(15,23,42,0.18)',
        'glow': '0 0 0 1px rgba(255,122,20,0.16), 0 8px 32px -8px rgba(255,122,20,0.32)',
      },
      keyframes: {
        'fade-in':   { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        'pop':       { '0%': { transform: 'scale(0.92)' }, '100%': { transform: 'scale(1)' } },
        'slide-up':  { '0%': { transform: 'translateY(100%)' }, '100%': { transform: 'translateY(0)' } },
        shimmer:     { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
      },
      animation: {
        'fade-in':  'fade-in 0.35s ease-out',
        'pop':      'pop 0.18s ease-out',
        'slide-up': 'slide-up 0.3s cubic-bezier(0.22, 1, 0.36, 1)',
        shimmer:    'shimmer 1.8s linear infinite',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};
export default config;
