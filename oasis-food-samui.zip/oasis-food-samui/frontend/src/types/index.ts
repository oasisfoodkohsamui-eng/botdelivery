export type Lang = 'en' | 'uk' | 'ru';

export interface Category {
  id: number;
  slug: string;
  icon: string | null;
  title: string;
  sort_order: number;
}

export interface Dish {
  id: number;
  slug: string;
  category_id: number;
  category_slug: string;
  image_url: string | null;
  price: number;
  currency: string;
  weight_grams: number | null;
  name: string;
  description: string | null;
  featured: boolean;
}

export interface DishDetail extends Dish {
  ingredients?: string | null;
  related?: Dish[];
}

export interface CartItem {
  id: number;
  dish_id: number;
  quantity: number;
  name: string;
  image_url: string | null;
  price: number;
  subtotal: number;
}

export interface Cart {
  items: CartItem[];
  total: number;
  items_count: number;
  currency: string;
}

export type OrderStatus =
  | 'pending'
  | 'accepted'
  | 'cooking'
  | 'delivering'
  | 'delivered'
  | 'cancelled';

export interface OrderItem {
  id: number;
  dish_id: number;
  dish_name: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: number;
  order_number: string;
  status: OrderStatus;
  total_price: number;
  currency: string;
  customer_name: string;
  phone: string;
  address: string;
  comment: string | null;
  created_at: string;
  items: OrderItem[];
}

export interface User {
  id: number;
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  name: string | null;
  phone: string | null;
  language: string;
  is_admin: boolean;
}
