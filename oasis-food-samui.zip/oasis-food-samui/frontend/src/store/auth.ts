import { create } from 'zustand';
import { api } from '@/lib/api';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  token: string | null;
  ready: boolean;
  authenticate: (initData: string) => Promise<void>;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  token: null,
  ready: false,
  authenticate: async (initData: string) => {
    try {
      const { data } = await api.post('/auth/telegram', { init_data: initData });
      if (typeof window !== 'undefined') localStorage.setItem('token', data.access_token);
      set({ user: data.user, token: data.access_token, ready: true });
    } catch (e) {
      set({ ready: true });
      throw e;
    }
  },
  logout: () => {
    if (typeof window !== 'undefined') localStorage.removeItem('token');
    set({ user: null, token: null });
  },
}));
