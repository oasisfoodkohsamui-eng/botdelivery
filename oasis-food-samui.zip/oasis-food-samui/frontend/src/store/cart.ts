import { create } from 'zustand';
import { api } from '@/lib/api';
import type { Cart } from '@/types';

interface CartState {
  cart: Cart;
  loading: boolean;
  fetch: () => Promise<void>;
  add: (dishId: number, qty?: number) => Promise<void>;
  update: (itemId: number, qty: number) => Promise<void>;
  remove: (itemId: number) => Promise<void>;
  clear: () => Promise<void>;
}

const emptyCart: Cart = { items: [], total: 0, items_count: 0, currency: 'THB' };

export const useCart = create<CartState>((set, get) => ({
  cart: emptyCart,
  loading: false,
  fetch: async () => {
    set({ loading: true });
    try {
      const { data } = await api.get<Cart>('/cart');
      set({ cart: data });
    } finally {
      set({ loading: false });
    }
  },
  add: async (dishId, qty = 1) => {
    const { data } = await api.post<Cart>('/cart/add', { dish_id: dishId, quantity: qty });
    set({ cart: data });
  },
  update: async (itemId, qty) => {
    const { data } = await api.patch<Cart>(`/cart/item/${itemId}`, { quantity: qty });
    set({ cart: data });
  },
  remove: async (itemId) => {
    const { data } = await api.delete<Cart>(`/cart/item/${itemId}`);
    set({ cart: data });
  },
  clear: async () => {
    const { data } = await api.delete<Cart>('/cart');
    set({ cart: data });
  },
}));
