'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, UtensilsCrossed, ShoppingBag, ReceiptText } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useCart } from '@/store/cart';
import { cn } from '@/lib/utils';

const tabs = [
  { href: '/',       icon: Home,              labelKey: 'nav.home' },
  { href: '/menu',   icon: UtensilsCrossed,   labelKey: 'nav.menu' },
  { href: '/cart',   icon: ShoppingBag,       labelKey: 'nav.cart', cart: true },
  { href: '/orders', icon: ReceiptText,       labelKey: 'nav.orders' },
];

export function BottomNav() {
  const pathname = usePathname();
  const { t } = useI18n();
  const count = useCart((s) => s.cart.items_count);

  return (
    <nav className="glass fixed inset-x-0 bottom-0 z-40 safe-bottom">
      <ul className="mx-auto grid max-w-xl grid-cols-4 px-3 pt-2">
        {tabs.map(({ href, icon: Icon, labelKey, cart }) => {
          const active = href === '/' ? pathname === '/' : pathname.startsWith(href);
          return (
            <li key={href}>
              <Link href={href} className="flex flex-col items-center gap-0.5 py-1.5">
                <span className={cn('relative inline-flex h-9 w-12 items-center justify-center rounded-2xl transition-all',
                  active && 'bg-[color-mix(in_srgb,var(--tg-button)_18%,transparent)]')}>
                  <Icon size={20} className={active ? 'text-[var(--tg-button)]' : 'text-[var(--tg-hint)]'} strokeWidth={active ? 2.4 : 1.8} />
                  {cart && count > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-[var(--tg-button)] px-1 text-[11px] font-bold text-white shadow-glow">
                      {count}
                    </span>
                  )}
                </span>
                <span className={cn('text-[11px] font-medium', active ? 'text-[var(--tg-text)]' : 'text-[var(--tg-hint)]')}>
                  {t(labelKey)}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
