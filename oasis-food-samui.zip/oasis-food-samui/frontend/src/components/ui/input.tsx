import * as React from 'react';
import { cn } from '@/lib/utils';

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        'h-12 w-full rounded-2xl border border-[color-mix(in_srgb,var(--tg-text)_10%,transparent)] bg-[var(--tg-secondary-bg)] px-4 text-[15px] outline-none transition-colors placeholder:text-[var(--tg-hint)] focus:border-[var(--tg-button)]',
        className
      )}
      {...props}
    />
  )
);
Input.displayName = 'Input';

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      rows={3}
      className={cn(
        'w-full rounded-2xl border border-[color-mix(in_srgb,var(--tg-text)_10%,transparent)] bg-[var(--tg-secondary-bg)] px-4 py-3 text-[15px] outline-none transition-colors placeholder:text-[var(--tg-hint)] focus:border-[var(--tg-button)]',
        className
      )}
      {...props}
    />
  )
);
Textarea.displayName = 'Textarea';
