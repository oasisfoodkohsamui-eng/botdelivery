import * as React from 'react';
import { cn } from '@/lib/utils';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'ghost' | 'outline';
  size?: 'sm' | 'md' | 'lg';
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', ...props }, ref) => {
    const base = 'inline-flex items-center justify-center gap-2 rounded-2xl font-semibold transition-all active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2';
    const sizes = {
      sm: 'h-9 px-3 text-sm',
      md: 'h-11 px-5 text-[15px]',
      lg: 'h-14 px-6 text-base',
    };
    const variants = {
      primary: 'btn-primary',
      ghost: 'btn-ghost',
      outline: 'border bg-transparent hover:bg-[var(--tg-secondary-bg)]',
    };
    return <button ref={ref} className={cn(base, sizes[size], variants[variant], className)} {...props} />;
  }
);
Button.displayName = 'Button';
