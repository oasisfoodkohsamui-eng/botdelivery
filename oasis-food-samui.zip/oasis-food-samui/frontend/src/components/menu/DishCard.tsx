'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Plus, Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState } from 'react';

import { useCart } from '@/store/cart';
import { useI18n } from '@/i18n';
import { haptic } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';
import type { Dish } from '@/types';

export function DishCard({ dish, index = 0 }: { dish: Dish; index?: number }) {
  const add = useCart((s) => s.add);
  const { t } = useI18n();
  const [added, setAdded] = useState(false);

  async function onAdd(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    haptic('light');
    try {
      await add(dish.id, 1);
      setAdded(true);
      haptic('success');
      setTimeout(() => setAdded(false), 1200);
    } catch {
      haptic('error');
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.04, 0.4), duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="card-surface group relative overflow-hidden rounded-3xl shadow-soft"
    >
      <Link href={`/dish/${dish.id}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden bg-[var(--tg-secondary-bg)]">
          {dish.image_url && (
            <Image
              src={dish.image_url}
              alt={dish.name}
              fill
              sizes="(max-width: 640px) 100vw, 50vw"
              className="object-cover transition-transform duration-500 group-active:scale-[1.03]"
            />
          )}
          {dish.featured && (
            <span className="absolute left-3 top-3 rounded-full bg-black/55 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-white backdrop-blur">
              ★ {t('home.featured')}
            </span>
          )}
        </div>
        <div className="space-y-1 p-3.5 pb-2">
          <h3 className="line-clamp-1 text-[15px] font-semibold leading-tight">{dish.name}</h3>
          {dish.description && (
            <p className="line-clamp-2 text-[12.5px] leading-snug text-[var(--tg-hint)]">{dish.description}</p>
          )}
        </div>
      </Link>
      <div className="flex items-center justify-between px-3.5 pb-3.5 pt-1">
        <span className="text-base font-bold">{formatPrice(dish.price, dish.currency)}</span>
        <button
          onClick={onAdd}
          className={`inline-flex h-9 items-center justify-center gap-1 rounded-full px-3.5 text-sm font-semibold transition-all active:scale-95 ${
            added
              ? 'bg-emerald-500 text-white'
              : 'bg-[var(--tg-button)] text-[var(--tg-button-text)] shadow-glow'
          }`}
          aria-label="Add to cart"
        >
          {added ? <Check size={16} /> : <Plus size={16} />}
          <span>{added ? t('menu.added') : t('menu.addToCart')}</span>
        </button>
      </div>
    </motion.div>
  );
}
