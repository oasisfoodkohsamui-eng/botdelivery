'use client';

import { cn } from '@/lib/utils';
import { haptic } from '@/lib/telegram';
import { useI18n } from '@/i18n';
import type { Category } from '@/types';

interface Props {
  categories: Category[];
  active: string | null;
  onSelect: (slug: string | null) => void;
  showAll?: boolean;
}

export function CategoryChips({ categories, active, onSelect, showAll = true }: Props) {
  const { t } = useI18n();
  return (
    <div className="no-scrollbar -mx-4 overflow-x-auto px-4">
      <div className="flex gap-2 pb-1">
        {showAll && (
          <button
            onClick={() => { haptic('light'); onSelect(null); }}
            className={cn('chip whitespace-nowrap', active === null && 'chip-active')}
          >
            ✨ {t('menu.all')}
          </button>
        )}
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => { haptic('light'); onSelect(c.slug); }}
            className={cn('chip whitespace-nowrap', active === c.slug && 'chip-active')}
          >
            {c.icon} {c.title}
          </button>
        ))}
      </div>
    </div>
  );
}
