'use client';

import { useRouter } from 'next/navigation';
import { ShoppingBag } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { useCart } from '@/store/cart';
import { useI18n } from '@/i18n';
import { haptic } from '@/lib/telegram';

export function FloatingCart() {
  const router = useRouter();
  const { cart } = useCart();
  const { t } = useI18n();

  return (
    <AnimatePresence>
      {cart.items_count > 0 && (
        <motion.button
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          onClick={() => { haptic('light'); router.push('/cart'); }}
          className="fixed bottom-20 left-1/2 z-30 flex h-14 -translate-x-1/2 items-center gap-3 rounded-full bg-[var(--tg-button)] px-5 text-[var(--tg-button-text)] shadow-soft-lg active:scale-[0.98]"
        >
          <span className="flex h-8 min-w-8 items-center justify-center rounded-full bg-white/20 px-2 text-sm font-bold">
            {cart.items_count}
          </span>
          <ShoppingBag size={20} />
          <span className="font-semibold">{Math.round(cart.total)} THB</span>
        </motion.button>
      )}
    </AnimatePresence>
  );
}
