'use client';

import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useRouter } from 'next/navigation';
import type { Lang } from '@/types';
import { haptic } from '@/lib/telegram';

interface Props {
  title?: string;
  back?: boolean;
  showLang?: boolean;
}

const LANG_FLAGS: Record<Lang, string> = { en: '🇬🇧', uk: '🇺🇦', ru: '🇷🇺' };

export function TopBar({ title, back, showLang = true }: Props) {
  const { lang, setLang } = useI18n();
  const router = useRouter();
  return (
    <header className="glass sticky top-0 z-30 safe-top">
      <div className="mx-auto flex h-14 max-w-xl items-center justify-between px-4">
        <div className="flex items-center gap-2">
          {back ? (
            <button
              onClick={() => { haptic('light'); router.back(); }}
              className="-ml-2 inline-flex h-10 w-10 items-center justify-center rounded-full active:bg-[var(--tg-secondary-bg)]"
              aria-label="Back"
            >
              <ArrowLeft size={20} />
            </button>
          ) : (
            <Link href="/" className="text-lg font-extrabold tracking-tight">
              Oasis<span className="text-brand-500">·</span>Food
            </Link>
          )}
          {title && <span className="ml-1 text-base font-semibold">{title}</span>}
        </div>
        {showLang && (
          <div className="flex gap-1">
            {(['en', 'uk', 'ru'] as Lang[]).map((l) => (
              <button
                key={l}
                onClick={() => { haptic('light'); setLang(l); }}
                className={`h-9 w-9 rounded-full text-base transition-all ${
                  lang === l ? 'bg-[var(--tg-button)] text-white shadow-glow' : 'bg-[var(--tg-secondary-bg)]'
                }`}
                aria-label={`Language ${l}`}
              >
                {LANG_FLAGS[l]}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
