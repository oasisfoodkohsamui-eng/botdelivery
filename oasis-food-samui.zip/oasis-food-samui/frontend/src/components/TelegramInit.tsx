'use client';

import { useEffect } from 'react';
import { applyTelegramTheme, getTg } from '@/lib/telegram';
import { useAuth } from '@/store/auth';
import { useCart } from '@/store/cart';
import { useI18n } from '@/i18n';
import type { Lang } from '@/types';

export function TelegramInit({ children }: { children: React.ReactNode }) {
  const { authenticate } = useAuth();
  const fetchCart = useCart((s) => s.fetch);
  const { setLang } = useI18n();

  useEffect(() => {
    const tg = getTg();
    if (tg) {
      tg.ready();
      tg.expand();
      applyTelegramTheme();
      tg.onEvent('themeChanged', applyTelegramTheme);

      const tgLang = (tg.initDataUnsafe?.user?.language_code || '').toLowerCase();
      if (tgLang.startsWith('uk')) setLang('uk' as Lang);
      else if (tgLang.startsWith('ru')) setLang('ru' as Lang);

      if (tg.initData) {
        authenticate(tg.initData).then(() => fetchCart()).catch(() => {});
      } else if (process.env.NODE_ENV === 'development') {
        // Dev fallback: try cart with any stored token
        fetchCart().catch(() => {});
      }
    } else if (process.env.NODE_ENV === 'development') {
      fetchCart().catch(() => {});
    }

    return () => {
      const tg2 = getTg();
      if (tg2) tg2.offEvent('themeChanged', applyTelegramTheme);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <>{children}</>;
}
