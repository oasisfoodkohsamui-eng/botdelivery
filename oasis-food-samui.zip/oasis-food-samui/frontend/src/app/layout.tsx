import type { Metadata, Viewport } from 'next';
import Script from 'next/script';
import { Inter, Manrope } from 'next/font/google';
import { Providers } from '@/components/Providers';
import './globals.css';

const sans = Inter({ subsets: ['latin', 'cyrillic'], variable: '--font-sans', display: 'swap' });
const display = Manrope({ subsets: ['latin', 'cyrillic'], weight: ['600', '700', '800'], variable: '--font-display', display: 'swap' });

export const metadata: Metadata = {
  title: 'Oasis Food Samui',
  description: 'Authentic flavors delivered to your door on Koh Samui',
  applicationName: 'Oasis Food',
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: '#ffffff',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${sans.variable} ${display.variable}`}>
      <head>
        <Script src="https://telegram.org/js/telegram-web-app.js" strategy="beforeInteractive" />
      </head>
      <body className="bg-atmosphere min-h-screen">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
