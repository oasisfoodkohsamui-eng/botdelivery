'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { useQuery } from '@tanstack/react-query';
import { Minus, Plus } from 'lucide-react';
import { motion } from 'framer-motion';

import { api } from '@/lib/api';
import { useI18n } from '@/i18n';
import { useCart } from '@/store/cart';
import { TopBar } from '@/components/TopBar';
import { DishCard } from '@/components/menu/DishCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { haptic } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';
import type { DishDetail } from '@/types';

export default function DishDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { t, lang } = useI18n();
  const add = useCart((s) => s.add);
  const [qty, setQty] = useState(1);
  const [adding, setAdding] = useState(false);

  const { data, isLoading } = useQuery<DishDetail>({
    queryKey: ['dish', id, lang],
    queryFn: async () => (await api.get(`/dishes/${id}`)).data,
  });

  async function onAdd() {
    if (!data) return;
    setAdding(true);
    haptic('light');
    try {
      await add(data.id, qty);
      haptic('success');
      router.push('/cart');
    } catch {
      haptic('error');
    } finally {
      setAdding(false);
    }
  }

  return (
    <>
      <TopBar back showLang={false} />
      <main className="mx-auto max-w-xl pb-40">
        <div className="relative aspect-square w-full overflow-hidden bg-[var(--tg-secondary-bg)]">
          {isLoading ? (
            <Skeleton className="h-full w-full rounded-none" />
          ) : data?.image_url ? (
            <Image src={data.image_url} alt={data.name} fill priority sizes="100vw" className="object-cover" />
          ) : null}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="-mt-6 rounded-t-3xl bg-[var(--tg-bg)] p-5"
        >
          {isLoading || !data ? (
            <div className="space-y-3">
              <Skeleton className="h-7 w-3/4" />
              <Skeleton className="h-4 w-1/3" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : (
            <>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h1 className="font-display text-2xl font-extrabold leading-tight">{data.name}</h1>
                  {data.weight_grams && (
                    <p className="mt-1 text-sm text-[var(--tg-hint)]">{t('dish.weight')}: {data.weight_grams}g</p>
                  )}
                </div>
                <span className="rounded-full bg-[var(--tg-secondary-bg)] px-3 py-1.5 text-base font-bold">
                  {formatPrice(data.price)}
                </span>
              </div>

              {data.description && (
                <p className="mt-4 text-[15px] leading-relaxed text-[var(--tg-text)]">{data.description}</p>
              )}

              {data.ingredients && (
                <section className="mt-6">
                  <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-[var(--tg-hint)]">
                    {t('dish.ingredients')}
                  </h3>
                  <p className="text-[14px] leading-relaxed">{data.ingredients}</p>
                </section>
              )}

              {data.related && data.related.length > 0 && (
                <section className="mt-8">
                  <h3 className="mb-3 font-display text-lg font-bold">{t('dish.related')}</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {data.related.map((d, i) => <DishCard key={d.id} dish={d} index={i} />)}
                  </div>
                </section>
              )}
            </>
          )}
        </motion.div>
      </main>

      {/* Sticky bottom action */}
      {data && (
        <div className="glass fixed inset-x-0 bottom-0 z-40 safe-bottom">
          <div className="mx-auto flex max-w-xl items-center gap-3 px-4 py-3">
            <div className="flex items-center gap-1 rounded-full bg-[var(--tg-secondary-bg)] p-1">
              <button
                onClick={() => { haptic('light'); setQty((q) => Math.max(1, q - 1)); }}
                className="grid h-9 w-9 place-items-center rounded-full active:scale-95"
              >
                <Minus size={16} />
              </button>
              <span className="w-7 text-center text-base font-bold">{qty}</span>
              <button
                onClick={() => { haptic('light'); setQty((q) => Math.min(99, q + 1)); }}
                className="grid h-9 w-9 place-items-center rounded-full active:scale-95"
              >
                <Plus size={16} />
              </button>
            </div>
            <Button onClick={onAdd} disabled={adding} className="flex-1" size="lg">
              {t('dish.addToCart', { total: Math.round(Number(data.price) * qty) })}
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
