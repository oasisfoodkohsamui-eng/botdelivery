'use client';

import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { ReceiptText, ChevronRight } from 'lucide-react';

import { api } from '@/lib/api';
import { useI18n } from '@/i18n';
import { TopBar } from '@/components/TopBar';
import { BottomNav } from '@/components/BottomNav';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { formatPrice } from '@/lib/utils';
import type { Order, OrderStatus } from '@/types';

const STATUS_COLOR: Record<OrderStatus, string> = {
  pending: 'bg-amber-500/15 text-amber-700 dark:text-amber-300',
  accepted: 'bg-blue-500/15 text-blue-700 dark:text-blue-300',
  cooking: 'bg-orange-500/15 text-orange-700 dark:text-orange-300',
  delivering: 'bg-violet-500/15 text-violet-700 dark:text-violet-300',
  delivered: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300',
  cancelled: 'bg-red-500/15 text-red-700 dark:text-red-300',
};

export default function OrdersPage() {
  const { t } = useI18n();

  const { data: orders = [], isLoading } = useQuery<Order[]>({
    queryKey: ['my-orders'],
    queryFn: async () => (await api.get('/orders')).data,
    refetchInterval: 30_000,
  });

  return (
    <>
      <TopBar title={t('order.myOrders')} />
      <main className="mx-auto max-w-xl px-4 pb-28 pt-3">
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)}
          </div>
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center py-20 text-center">
            <div className="grid h-24 w-24 place-items-center rounded-full bg-[var(--tg-secondary-bg)]">
              <ReceiptText size={36} className="text-[var(--tg-hint)]" />
            </div>
            <p className="mt-5 text-sm text-[var(--tg-hint)]">{t('order.noOrders')}</p>
            <Link href="/menu" className="mt-5">
              <Button>{t('cart.browseMenu')}</Button>
            </Link>
          </div>
        ) : (
          <ul className="space-y-3">
            {orders.map((o, i) => (
              <motion.li
                key={o.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.04, 0.3) }}
              >
                <Link
                  href={`/order/${o.id}`}
                  className="card-surface flex items-center gap-3 rounded-2xl p-4 shadow-soft active:scale-[0.99]"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-display text-sm font-bold">{o.order_number}</span>
                      <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${STATUS_COLOR[o.status]}`}>
                        {t(`order.status.${o.status}`)}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-[var(--tg-hint)]">
                      {new Date(o.created_at).toLocaleString()}
                    </p>
                    <p className="mt-1 line-clamp-1 text-xs text-[var(--tg-hint)]">
                      {o.items.map((it) => `${it.dish_name}×${it.quantity}`).join(' · ')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-base font-extrabold">{formatPrice(o.total_price)}</p>
                    <ChevronRight size={16} className="ml-auto mt-1 text-[var(--tg-hint)]" />
                  </div>
                </Link>
              </motion.li>
            ))}
          </ul>
        )}
      </main>
      <BottomNav />
    </>
  );
}
