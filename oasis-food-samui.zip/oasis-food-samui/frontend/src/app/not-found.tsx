import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <p className="text-7xl">🍃</p>
      <h1 className="mt-4 font-display text-2xl font-extrabold">404</h1>
      <p className="mt-1 text-[var(--tg-hint)]">Page not found</p>
      <Link href="/" className="mt-6 rounded-full bg-[var(--tg-button)] px-6 py-3 font-semibold text-[var(--tg-button-text)]">
        Home
      </Link>
    </div>
  );
}
