'use client';

import { useState, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { Search } from 'lucide-react';

import { api } from '@/lib/api';
import { useI18n } from '@/i18n';
import { TopBar } from '@/components/TopBar';
import { BottomNav } from '@/components/BottomNav';
import { DishCard } from '@/components/menu/DishCard';
import { CategoryChips } from '@/components/menu/CategoryChips';
import { DishCardSkeleton } from '@/components/ui/skeleton';
import { FloatingCart } from '@/components/cart/FloatingCart';
import type { Category, Dish } from '@/types';

export default function MenuPage() {
  const { t, lang } = useI18n();
  const params = useSearchParams();
  const initialCat = params.get('category');
  const [active, setActive] = useState<string | null>(initialCat);
  const [query, setQuery] = useState('');

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['categories', lang],
    queryFn: async () => (await api.get('/categories')).data,
  });
  const { data: dishes = [], isLoading } = useQuery<Dish[]>({
    queryKey: ['dishes', lang, active],
    queryFn: async () =>
      (await api.get('/dishes', { params: active ? { category: active } : {} })).data,
  });

  const filtered = useMemo(() => {
    if (!query) return dishes;
    const q = query.toLowerCase();
    return dishes.filter(
      (d) => d.name.toLowerCase().includes(q) || (d.description || '').toLowerCase().includes(q)
    );
  }, [dishes, query]);

  return (
    <>
      <TopBar title={t('menu.title')} />
      <main className="mx-auto max-w-xl px-4 pb-32 pt-3">
        <div className="relative mb-4">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--tg-hint)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('common.search')}
            className="h-12 w-full rounded-2xl bg-[var(--tg-secondary-bg)] pl-11 pr-4 text-[15px] outline-none placeholder:text-[var(--tg-hint)]"
          />
        </div>

        <CategoryChips categories={categories} active={active} onSelect={setActive} />

        <div className="mt-4 grid grid-cols-2 gap-3">
          {isLoading
            ? Array.from({ length: 6 }).map((_, i) => <DishCardSkeleton key={i} />)
            : filtered.length === 0
            ? (
              <div className="col-span-2 py-16 text-center text-[var(--tg-hint)]">
                <p className="text-4xl">🍽</p>
                <p className="mt-2 text-sm">{t('common.empty')}</p>
              </div>
            )
            : filtered.map((d, i) => <DishCard key={d.id} dish={d} index={i} />)}
        </div>
      </main>
      <FloatingCart />
      <BottomNav />
    </>
  );
}
