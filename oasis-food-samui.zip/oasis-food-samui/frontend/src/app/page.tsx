'use client';

import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Clock, Truck, MapPin } from 'lucide-react';

import { api } from '@/lib/api';
import { useI18n } from '@/i18n';
import { useAuth } from '@/store/auth';
import { TopBar } from '@/components/TopBar';
import { BottomNav } from '@/components/BottomNav';
import { DishCard } from '@/components/menu/DishCard';
import { DishCardSkeleton } from '@/components/ui/skeleton';
import { FloatingCart } from '@/components/cart/FloatingCart';
import type { Category, Dish } from '@/types';

export default function HomePage() {
  const { t, lang } = useI18n();
  const user = useAuth((s) => s.user);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['categories', lang],
    queryFn: async () => (await api.get('/categories')).data,
  });
  const { data: featured = [], isLoading } = useQuery<Dish[]>({
    queryKey: ['dishes', 'featured', lang],
    queryFn: async () => (await api.get('/dishes', { params: { featured: true, limit: 8 } })).data,
  });

  const greeting = user?.first_name ? t('home.hello', { name: user.first_name }) : t('home.welcome');

  return (
    <>
      <TopBar />
      <main className="mx-auto max-w-xl px-4 pb-32 pt-2">
        {/* Hero */}
        <motion.section
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-500 via-brand-400 to-brand-600 p-6 text-white shadow-soft-lg"
        >
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/15 blur-2xl" />
          <div className="absolute -bottom-12 -left-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
          <div className="relative">
            <p className="text-sm font-medium opacity-90">{greeting}</p>
            <h1 className="font-display mt-1 text-2xl font-extrabold leading-tight tracking-tight">
              {t('home.tagline')}
            </h1>
            <div className="mt-4 flex flex-wrap gap-2 text-xs font-medium">
              <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 backdrop-blur">
                <Clock size={12} /> {t('home.delivery')}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 backdrop-blur">
                <Truck size={12} /> {t('home.deliveryInfo')}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 backdrop-blur">
                <MapPin size={12} /> Koh Samui
              </span>
            </div>
          </div>
        </motion.section>

        {/* Categories */}
        <section className="mt-8">
          <div className="mb-3 flex items-end justify-between px-1">
            <h2 className="font-display text-lg font-bold">{t('home.categories')}</h2>
            <Link href="/menu" className="text-sm font-semibold text-[var(--tg-link)]">{t('home.viewAll')} →</Link>
          </div>
          <div className="no-scrollbar -mx-4 overflow-x-auto px-4">
            <div className="flex gap-2.5">
              {categories.map((c) => (
                <Link
                  key={c.id}
                  href={`/menu?category=${c.slug}`}
                  className="flex min-w-[88px] flex-col items-center gap-2 rounded-2xl bg-[var(--tg-secondary-bg)] p-3 text-center active:scale-[0.97]"
                >
                  <span className="text-2xl">{c.icon}</span>
                  <span className="text-xs font-medium">{c.title}</span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured */}
        <section className="mt-8">
          <div className="mb-3 flex items-end justify-between px-1">
            <h2 className="font-display text-lg font-bold">{t('home.featured')}</h2>
            <Link href="/menu" className="text-sm font-semibold text-[var(--tg-link)]">{t('home.viewAll')} →</Link>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {isLoading
              ? Array.from({ length: 4 }).map((_, i) => <DishCardSkeleton key={i} />)
              : featured.map((d, i) => <DishCard key={d.id} dish={d} index={i} />)}
          </div>
        </section>
      </main>
      <FloatingCart />
      <BottomNav />
    </>
  );
}
