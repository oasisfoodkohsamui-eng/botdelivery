'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

import { TopBar } from '@/components/TopBar';
import { BottomNav } from '@/components/BottomNav';
import { Button } from '@/components/ui/button';
import { useCart } from '@/store/cart';
import { useI18n } from '@/i18n';
import { haptic } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';

export default function CartPage() {
  const router = useRouter();
  const { t } = useI18n();
  const { cart, loading, fetch, update, remove, clear } = useCart();

  useEffect(() => { fetch().catch(() => {}); }, [fetch]);

  if (!loading && cart.items.length === 0) {
    return (
      <>
        <TopBar title={t('cart.title')} back />
        <main className="mx-auto flex max-w-xl flex-col items-center justify-center px-4 py-24 text-center">
          <div className="grid h-24 w-24 place-items-center rounded-full bg-[var(--tg-secondary-bg)]">
            <ShoppingBag size={36} className="text-[var(--tg-hint)]" />
          </div>
          <h2 className="mt-5 font-display text-xl font-bold">{t('cart.empty')}</h2>
          <p className="mt-1 text-sm text-[var(--tg-hint)]">{t('cart.emptyDesc')}</p>
          <Link href="/menu" className="mt-6">
            <Button>{t('cart.browseMenu')}</Button>
          </Link>
        </main>
        <BottomNav />
      </>
    );
  }

  return (
    <>
      <TopBar title={t('cart.title')} back />
      <main className="mx-auto max-w-xl px-4 pb-36 pt-3">
        <div className="space-y-3">
          <AnimatePresence initial={false}>
            {cart.items.map((it) => (
              <motion.div
                key={it.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -40 }}
                className="card-surface flex items-center gap-3 rounded-2xl p-2.5 shadow-soft"
              >
                <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-[var(--tg-secondary-bg)]">
                  {it.image_url && <Image src={it.image_url} alt={it.name} fill sizes="80px" className="object-cover" />}
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="line-clamp-2 text-sm font-semibold leading-tight">{it.name}</h3>
                  <p className="mt-1 text-base font-bold text-[var(--tg-button)]">{formatPrice(it.subtotal)}</p>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <button
                    onClick={() => { haptic('light'); remove(it.id); }}
                    className="grid h-7 w-7 place-items-center rounded-full text-[var(--tg-hint)] active:bg-[var(--tg-secondary-bg)]"
                    aria-label={t('cart.remove')}
                  >
                    <Trash2 size={15} />
                  </button>
                  <div className="flex items-center gap-1 rounded-full bg-[var(--tg-secondary-bg)] p-0.5">
                    <button
                      onClick={() => { haptic('light'); update(it.id, Math.max(0, it.quantity - 1)); }}
                      className="grid h-7 w-7 place-items-center rounded-full active:scale-95"
                    >
                      <Minus size={13} />
                    </button>
                    <span className="w-6 text-center text-sm font-bold">{it.quantity}</span>
                    <button
                      onClick={() => { haptic('light'); update(it.id, it.quantity + 1); }}
                      className="grid h-7 w-7 place-items-center rounded-full bg-[var(--tg-button)] text-[var(--tg-button-text)] active:scale-95"
                    >
                      <Plus size={13} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <button
          onClick={() => { haptic('warning'); clear(); }}
          className="mx-auto mt-5 block text-sm font-medium text-[var(--tg-hint)] underline-offset-4 hover:underline"
        >
          {t('cart.clear')}
        </button>

        <section className="mt-6 rounded-2xl bg-[var(--tg-secondary-bg)] p-4 text-sm">
          <div className="flex justify-between py-1.5">
            <span className="text-[var(--tg-hint)]">{t('cart.subtotal')}</span>
            <span className="font-semibold">{formatPrice(cart.total)}</span>
          </div>
          <div className="flex justify-between py-1.5">
            <span className="text-[var(--tg-hint)]">{t('cart.delivery')}</span>
            <span className="font-semibold">{cart.total >= 800 ? t('cart.free') : '60 THB'}</span>
          </div>
          <div className="mt-2 flex justify-between border-t border-[color-mix(in_srgb,var(--tg-text)_10%,transparent)] pt-3">
            <span className="font-bold">{t('cart.total')}</span>
            <span className="font-display text-lg font-extrabold">
              {formatPrice(cart.total + (cart.total >= 800 ? 0 : 60))}
            </span>
          </div>
        </section>
      </main>

      <div className="glass fixed inset-x-0 bottom-0 z-30 safe-bottom">
        <div className="mx-auto max-w-xl px-4 py-3">
          <Button
            onClick={() => { haptic('light'); router.push('/checkout'); }}
            className="w-full"
            size="lg"
          >
            {t('cart.checkout', { total: Math.round(cart.total) })}
          </Button>
        </div>
      </div>
    </>
  );
}
