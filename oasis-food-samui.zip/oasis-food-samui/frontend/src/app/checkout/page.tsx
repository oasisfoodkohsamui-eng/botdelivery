'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

import { api } from '@/lib/api';
import { useCart } from '@/store/cart';
import { useAuth } from '@/store/auth';
import { useI18n } from '@/i18n';
import { TopBar } from '@/components/TopBar';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { haptic } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';
import type { Order } from '@/types';

interface FormData {
  name: string;
  phone: string;
  address: string;
  comment?: string;
}

export default function CheckoutPage() {
  const router = useRouter();
  const { t, lang } = useI18n();
  const { cart, fetch: refreshCart } = useCart();
  const user = useAuth((s) => s.user);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [form, setForm] = useState<FormData>({ name: '', phone: '', address: '', comment: '' });

  useEffect(() => { refreshCart().catch(() => {}); }, [refreshCart]);

  useEffect(() => {
    if (user) {
      setForm((f) => ({
        ...f,
        name: f.name || user.name || [user.first_name, user.last_name].filter(Boolean).join(' '),
        phone: f.phone || user.phone || '',
      }));
    }
  }, [user]);

  function validate(): boolean {
    const e: typeof errors = {};
    if (form.name.trim().length < 2) e.name = t('checkout.errors.name');
    if (form.phone.replace(/\D/g, '').length < 6) e.phone = t('checkout.errors.phone');
    if (form.address.trim().length < 3) e.address = t('checkout.errors.address');
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function submit() {
    if (!validate()) { haptic('error'); return; }
    setSubmitting(true);
    try {
      const { data } = await api.post<Order>('/orders/checkout', {
        name: form.name.trim(),
        phone: form.phone.trim(),
        address: form.address.trim(),
        comment: form.comment?.trim() || null,
        language: lang,
      });
      haptic('success');
      await refreshCart();
      router.replace(`/order/${data.id}?new=1`);
    } catch (err: any) {
      haptic('error');
      alert(err?.response?.data?.detail || t('common.error'));
    } finally {
      setSubmitting(false);
    }
  }

  const deliveryFee = cart.total >= 800 ? 0 : 60;
  const grandTotal = cart.total + deliveryFee;

  return (
    <>
      <TopBar title={t('checkout.title')} back />
      <main className="mx-auto max-w-xl px-4 pb-36 pt-3">
        <form
          onSubmit={(e) => { e.preventDefault(); submit(); }}
          className="space-y-4"
        >
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-[var(--tg-hint)]">
              {t('checkout.name')}
            </label>
            <Input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              autoComplete="name"
            />
            {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-[var(--tg-hint)]">
              {t('checkout.phone')}
            </label>
            <Input
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              inputMode="tel"
              type="tel"
              placeholder="+66 ..."
              autoComplete="tel"
            />
            {errors.phone && <p className="mt-1 text-xs text-red-500">{errors.phone}</p>}
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-[var(--tg-hint)]">
              {t('checkout.address')}
            </label>
            <Textarea
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              placeholder={t('checkout.addressHint')}
              rows={2}
            />
            {errors.address && <p className="mt-1 text-xs text-red-500">{errors.address}</p>}
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-[var(--tg-hint)]">
              {t('checkout.comment')}
            </label>
            <Textarea
              value={form.comment}
              onChange={(e) => setForm({ ...form, comment: e.target.value })}
              rows={2}
            />
          </div>

          <section className="rounded-2xl bg-[var(--tg-secondary-bg)] p-4 text-sm">
            <div className="flex justify-between py-1">
              <span className="text-[var(--tg-hint)]">{t('cart.subtotal')}</span>
              <span className="font-semibold">{formatPrice(cart.total)}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[var(--tg-hint)]">{t('cart.delivery')}</span>
              <span className="font-semibold">{deliveryFee === 0 ? t('cart.free') : formatPrice(deliveryFee)}</span>
            </div>
            <div className="mt-2 flex justify-between border-t border-[color-mix(in_srgb,var(--tg-text)_10%,transparent)] pt-3">
              <span className="font-bold">{t('cart.total')}</span>
              <span className="font-display text-lg font-extrabold">{formatPrice(grandTotal)}</span>
            </div>
          </section>
        </form>
      </main>

      <div className="glass fixed inset-x-0 bottom-0 z-30 safe-bottom">
        <div className="mx-auto max-w-xl px-4 py-3">
          <Button
            onClick={submit}
            disabled={submitting || cart.items.length === 0}
            className="w-full"
            size="lg"
          >
            {submitting ? '...' : t('checkout.place', { total: Math.round(grandTotal) })}
          </Button>
        </div>
      </div>
    </>
  );
}
