export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="relative">
        <div className="h-12 w-12 rounded-full border-2 border-[var(--tg-secondary-bg)]" />
        <div className="absolute inset-0 h-12 w-12 animate-spin rounded-full border-2 border-transparent border-t-[var(--tg-button)]" />
      </div>
    </div>
  );
}
