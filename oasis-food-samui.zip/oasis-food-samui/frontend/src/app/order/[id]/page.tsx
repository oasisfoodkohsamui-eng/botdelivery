'use client';

import { useEffect } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { CheckCircle2, Clock, ChefHat, Bike, Package, XCircle } from 'lucide-react';

import { api } from '@/lib/api';
import { useI18n } from '@/i18n';
import { TopBar } from '@/components/TopBar';
import { BottomNav } from '@/components/BottomNav';
import { Skeleton } from '@/components/ui/skeleton';
import { haptic } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';
import type { Order, OrderStatus } from '@/types';

const STATUS_FLOW: OrderStatus[] = ['pending', 'accepted', 'cooking', 'delivering', 'delivered'];

const STATUS_ICONS: Record<OrderStatus, React.ElementType> = {
  pending: Clock,
  accepted: CheckCircle2,
  cooking: ChefHat,
  delivering: Bike,
  delivered: Package,
  cancelled: XCircle,
};

export default function OrderPage() {
  const { id } = useParams<{ id: string }>();
  const params = useSearchParams();
  const isNew = params.get('new') === '1';
  const { t } = useI18n();

  useEffect(() => { if (isNew) haptic('success'); }, [isNew]);

  const { data: order, isLoading } = useQuery<Order>({
    queryKey: ['order', id],
    queryFn: async () => (await api.get(`/orders/${id}`)).data,
    refetchInterval: (q) => {
      const status = (q.state.data as Order | undefined)?.status;
      return status && status !== 'delivered' && status !== 'cancelled' ? 15_000 : false;
    },
  });

  return (
    <>
      <TopBar title={t('order.trackTitle')} back />
      <main className="mx-auto max-w-xl px-4 pb-32 pt-3">
        {isNew && (
          <motion.section
            initial={{ scale: 0.92, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 380, damping: 28 }}
            className="mb-5 overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-500 to-emerald-600 p-6 text-white shadow-soft-lg"
          >
            <CheckCircle2 size={42} strokeWidth={2} />
            <h1 className="font-display mt-3 text-2xl font-extrabold">{t('order.received')}</h1>
            <p className="mt-1 text-sm opacity-90">{t('order.estDelivery')}</p>
          </motion.section>
        )}

        {isLoading || !order ? (
          <div className="space-y-3">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        ) : (
          <>
            <section className="card-surface rounded-3xl p-5 shadow-soft">
              <div className="flex items-baseline justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wider text-[var(--tg-hint)]">
                    {t('order.number')}
                  </p>
                  <p className="font-display text-xl font-extrabold">{order.order_number}</p>
                </div>
                <p className="font-display text-xl font-extrabold">{formatPrice(order.total_price)}</p>
              </div>

              <div className="mt-5">
                {order.status === 'cancelled' ? (
                  <div className="flex items-center gap-2 rounded-2xl bg-red-50 px-4 py-3 text-red-700 dark:bg-red-950/40 dark:text-red-300">
                    <XCircle size={18} />
                    <span className="font-semibold">{t('order.status.cancelled')}</span>
                  </div>
                ) : (
                  <ol className="relative space-y-3">
                    {STATUS_FLOW.map((s) => {
                      const reached = STATUS_FLOW.indexOf(order.status) >= STATUS_FLOW.indexOf(s);
                      const current = order.status === s;
                      const Icon = STATUS_ICONS[s];
                      return (
                        <li key={s} className="flex items-center gap-3">
                          <span
                            className={`grid h-9 w-9 place-items-center rounded-full transition-all ${
                              reached ? 'bg-[var(--tg-button)] text-[var(--tg-button-text)] shadow-glow' : 'bg-[var(--tg-secondary-bg)] text-[var(--tg-hint)]'
                            } ${current ? 'animate-pop' : ''}`}
                          >
                            <Icon size={16} />
                          </span>
                          <span className={`text-sm ${reached ? 'font-semibold' : 'text-[var(--tg-hint)]'}`}>
                            {t(`order.status.${s}`)}
                          </span>
                        </li>
                      );
                    })}
                  </ol>
                )}
              </div>
            </section>

            <section className="mt-5 rounded-3xl bg-[var(--tg-secondary-bg)] p-5 text-sm">
              <div className="space-y-1.5">
                <p><span className="text-[var(--tg-hint)]">{t('checkout.name')}: </span>{order.customer_name}</p>
                <p><span className="text-[var(--tg-hint)]">{t('checkout.phone')}: </span>{order.phone}</p>
                <p><span className="text-[var(--tg-hint)]">{t('checkout.address')}: </span>{order.address}</p>
                {order.comment && (
                  <p><span className="text-[var(--tg-hint)]">{t('checkout.comment')}: </span>{order.comment}</p>
                )}
              </div>
              <hr className="my-4 border-[color-mix(in_srgb,var(--tg-text)_10%,transparent)]" />
              <ul className="space-y-1.5">
                {order.items.map((it) => (
                  <li key={it.id} className="flex justify-between">
                    <span>{it.dish_name} × {it.quantity}</span>
                    <span className="font-semibold">{formatPrice(Number(it.price) * it.quantity)}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-3 flex justify-between border-t border-[color-mix(in_srgb,var(--tg-text)_10%,transparent)] pt-3">
                <span className="font-semibold">{t('cart.total')}</span>
                <span className="font-display font-extrabold">{formatPrice(order.total_price)}</span>
              </div>
            </section>
          </>
        )}
      </main>
      <BottomNav />
    </>
  );
}
