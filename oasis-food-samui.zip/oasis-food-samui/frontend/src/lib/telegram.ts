'use client';

// Lightweight Telegram WebApp wrapper — avoids hard dependency at SSR.

export type ThemeParams = {
  bg_color?: string;
  text_color?: string;
  hint_color?: string;
  link_color?: string;
  button_color?: string;
  button_text_color?: string;
  secondary_bg_color?: string;
};

export interface TelegramWebApp {
  initData: string;
  initDataUnsafe: any;
  themeParams: ThemeParams;
  colorScheme: 'light' | 'dark';
  ready(): void;
  expand(): void;
  close(): void;
  HapticFeedback?: {
    impactOccurred(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft'): void;
    notificationOccurred(type: 'error' | 'success' | 'warning'): void;
    selectionChanged(): void;
  };
  MainButton: {
    text: string;
    show(): void;
    hide(): void;
    enable(): void;
    disable(): void;
    onClick(cb: () => void): void;
    offClick(cb: () => void): void;
    setText(text: string): void;
    setParams(p: Partial<{ text: string; color: string; text_color: string; is_active: boolean; is_visible: boolean }>): void;
  };
  BackButton: {
    show(): void;
    hide(): void;
    onClick(cb: () => void): void;
    offClick(cb: () => void): void;
  };
  onEvent(ev: string, cb: () => void): void;
  offEvent(ev: string, cb: () => void): void;
  showAlert(message: string): void;
  showConfirm(message: string, cb: (ok: boolean) => void): void;
}

declare global {
  interface Window {
    Telegram?: { WebApp?: TelegramWebApp };
  }
}

export function getTg(): TelegramWebApp | null {
  if (typeof window === 'undefined') return null;
  return window.Telegram?.WebApp ?? null;
}

export function applyTelegramTheme() {
  const tg = getTg();
  if (!tg) return;
  const p = tg.themeParams || {};
  const root = document.documentElement;
  const set = (k: string, v?: string) => {
    if (v) root.style.setProperty(k, v);
  };
  set('--tg-bg', p.bg_color);
  set('--tg-text', p.text_color);
  set('--tg-hint', p.hint_color);
  set('--tg-link', p.link_color);
  set('--tg-button', p.button_color);
  set('--tg-button-text', p.button_text_color);
  set('--tg-secondary-bg', p.secondary_bg_color);
  if (tg.colorScheme === 'dark') root.classList.add('dark');
  else root.classList.remove('dark');
}

export function haptic(kind: 'light' | 'medium' | 'heavy' | 'success' | 'warning' | 'error' = 'light') {
  const tg = getTg();
  if (!tg?.HapticFeedback) return;
  if (kind === 'success' || kind === 'warning' || kind === 'error') {
    tg.HapticFeedback.notificationOccurred(kind);
  } else {
    tg.HapticFeedback.impactOccurred(kind);
  }
}
