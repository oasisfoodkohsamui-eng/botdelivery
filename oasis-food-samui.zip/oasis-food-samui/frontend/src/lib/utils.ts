import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(value: number | string, currency = 'THB'): string {
  const n = typeof value === 'string' ? Number(value) : value;
  return `${Math.round(n)} ${currency}`;
}
