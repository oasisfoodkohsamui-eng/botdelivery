'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import en from './locales/en.json';
import uk from './locales/uk.json';
import ru from './locales/ru.json';
import type { Lang } from '@/types';

const dictionaries: Record<Lang, any> = { en, uk, ru };

interface I18nCtx {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
}

const Ctx = createContext<I18nCtx | null>(null);

function lookup(dict: any, key: string): string | undefined {
  return key.split('.').reduce((acc: any, part) => (acc ? acc[part] : undefined), dict);
}

function interpolate(s: string, vars?: Record<string, string | number>) {
  if (!vars) return s;
  return s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? String(vars[k]) : `{${k}}`));
}

export function I18nProvider({ children, initialLang = 'en' }: { children: React.ReactNode; initialLang?: Lang }) {
  const [lang, setLang] = useState<Lang>(initialLang);

  useEffect(() => {
    const stored = typeof window !== 'undefined' ? (localStorage.getItem('lang') as Lang | null) : null;
    if (stored && ['en', 'uk', 'ru'].includes(stored)) setLang(stored);
  }, []);

  const change = useCallback((l: Lang) => {
    setLang(l);
    if (typeof window !== 'undefined') localStorage.setItem('lang', l);
  }, []);

  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => {
      const value = lookup(dictionaries[lang], key) ?? lookup(dictionaries.en, key) ?? key;
      return typeof value === 'string' ? interpolate(value, vars) : key;
    },
    [lang]
  );

  const value = useMemo(() => ({ lang, setLang: change, t }), [lang, change, t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
}
