import axios from 'axios';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export const api = axios.create({ baseURL: `${API}/api/v1`, timeout: 15000 });

api.interceptors.request.use((cfg) => {
  if (typeof window === 'undefined') return cfg;
  const token = localStorage.getItem('admin_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

export function setAdminToken(token: string) {
  localStorage.setItem('admin_token', token);
}
export function getAdminToken(): string | null {
  return typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;
}
export function clearAdminToken() {
  localStorage.removeItem('admin_token');
}
