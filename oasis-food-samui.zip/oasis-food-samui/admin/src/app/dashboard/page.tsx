'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from 'recharts';
import { ShoppingBag, Wallet, Clock, TrendingUp, LogOut } from 'lucide-react';

import { api, clearAdminToken, getAdminToken } from '@/lib/api';

export default function Dashboard() {
  const router = useRouter();

  useEffect(() => { if (!getAdminToken()) router.replace('/'); }, [router]);

  const { data: stats } = useQuery({
    queryKey: ['stats'],
    queryFn: async () => (await api.get('/admin/stats')).data,
    refetchInterval: 20_000,
  });
  const { data: chart = [] } = useQuery({
    queryKey: ['chart'],
    queryFn: async () => (await api.get('/admin/revenue-chart', { params: { days: 14 } })).data,
    refetchInterval: 60_000,
  });

  function logout() { clearAdminToken(); router.replace('/'); }

  const cards = [
    { label: 'Orders today',  value: stats?.orders_today ?? '—',   icon: ShoppingBag, accent: 'from-blue-500 to-blue-600' },
    { label: 'Revenue today', value: stats ? `${Math.round(Number(stats.revenue_today))} THB` : '—', icon: Wallet, accent: 'from-emerald-500 to-emerald-600' },
    { label: 'Pending',       value: stats?.pending_orders ?? '—', icon: Clock, accent: 'from-amber-500 to-amber-600' },
    { label: 'Total revenue', value: stats ? `${Math.round(Number(stats.revenue_total))} THB` : '—', icon: TrendingUp, accent: 'from-violet-500 to-violet-600' },
  ];

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 md:px-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Dashboard</h1>
          <p className="text-sm text-ink-500">Oasis Food Samui · live overview</p>
        </div>
        <nav className="flex items-center gap-3">
          <Link href="/orders" className="rounded-xl bg-ink-900 px-4 py-2 text-sm font-semibold text-white dark:bg-white dark:text-ink-900">Orders</Link>
          <Link href="/customers" className="rounded-xl border border-ink-200 px-4 py-2 text-sm font-semibold dark:border-white/15">Customers</Link>
          <button onClick={logout} className="grid h-10 w-10 place-items-center rounded-xl border border-ink-200 dark:border-white/15" aria-label="Logout">
            <LogOut size={16} />
          </button>
        </nav>
      </header>

      <section className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.map(({ label, value, icon: Icon, accent }) => (
          <div key={label} className="rounded-2xl border border-ink-200/60 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-white/5">
            <div className={`grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${accent} text-white`}>
              <Icon size={18} />
            </div>
            <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-ink-500">{label}</p>
            <p className="mt-1 text-2xl font-extrabold">{value}</p>
          </div>
        ))}
      </section>

      <section className="mt-6 rounded-2xl border border-ink-200/60 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-white/5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">Revenue · last 14 days</h2>
          <span className="text-xs text-ink-500">THB</span>
        </div>
        <div className="mt-3 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chart}>
              <CartesianGrid stroke="rgba(100,116,139,0.15)" strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="revenue" stroke="#ff7a14" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-ink-200/60 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-white/5">
        <h2 className="text-lg font-bold">Top dishes</h2>
        <ul className="mt-3 divide-y divide-ink-200/60 dark:divide-white/10">
          {(stats?.top_dishes ?? []).map((d: any, i: number) => (
            <li key={d.dish_id} className="flex items-center justify-between py-3">
              <span className="flex items-center gap-3">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-ink-100 text-sm font-bold dark:bg-white/10">{i + 1}</span>
                <span className="font-medium">{d.name}</span>
              </span>
              <span className="text-sm text-ink-500">× {d.quantity}</span>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
