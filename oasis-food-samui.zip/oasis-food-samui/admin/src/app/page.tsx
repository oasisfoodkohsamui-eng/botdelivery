'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, setAdminToken } from '@/lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [token, setToken] = useState('');
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    setLoading(true);
    try {
      setAdminToken(token.trim());
      const { data } = await api.get('/auth/me');
      if (!data.is_admin) throw new Error('Not an admin account');
      router.replace('/dashboard');
    } catch (e: any) {
      setErr(e?.response?.data?.detail || e?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen grid place-items-center px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border border-ink-200/60 bg-white p-6 shadow-sm dark:border-white/10 dark:bg-white/5">
        <h1 className="text-2xl font-bold tracking-tight">Oasis Admin</h1>
        <p className="mt-1 text-sm text-ink-500">Paste your admin JWT to continue.</p>
        <p className="mt-2 text-xs text-ink-500">
          Tip: open Mini App in Telegram as an admin, copy <code>token</code> from <code>localStorage</code>.
        </p>
        <textarea
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="eyJ..."
          rows={4}
          className="mt-4 w-full rounded-xl border border-ink-200/60 bg-ink-50 p-3 font-mono text-xs outline-none focus:border-brand-500 dark:bg-white/5"
        />
        {err && <p className="mt-2 text-sm text-red-500">{err}</p>}
        <button
          type="submit"
          disabled={loading || token.length < 10}
          className="mt-4 w-full rounded-xl bg-brand-500 px-5 py-3 font-semibold text-white transition-all hover:bg-brand-600 disabled:opacity-50"
        >
          {loading ? '...' : 'Continue'}
        </button>
      </form>
    </main>
  );
}
