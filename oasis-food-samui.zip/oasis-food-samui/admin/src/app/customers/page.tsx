'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import { ChevronLeft } from 'lucide-react';

import { api, getAdminToken } from '@/lib/api';

export default function CustomersAdmin() {
  const router = useRouter();
  useEffect(() => { if (!getAdminToken()) router.replace('/'); }, [router]);

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers'],
    queryFn: async () => (await api.get('/admin/customers')).data,
  });

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 md:px-8">
      <header className="flex items-center gap-3">
        <Link href="/dashboard" className="grid h-10 w-10 place-items-center rounded-xl border border-ink-200 dark:border-white/15">
          <ChevronLeft size={18} />
        </Link>
        <h1 className="text-3xl font-extrabold tracking-tight">Customers</h1>
      </header>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-ink-200/60 bg-white shadow-sm dark:border-white/10 dark:bg-white/5">
        <table className="w-full text-sm">
          <thead className="bg-ink-50 text-left text-xs uppercase tracking-wider text-ink-500 dark:bg-white/5">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Telegram</th>
              <th className="px-4 py-3">Phone</th>
              <th className="px-4 py-3 text-right">Orders</th>
              <th className="px-4 py-3 text-right">Spent</th>
              <th className="px-4 py-3">Joined</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-200/60 dark:divide-white/10">
            {isLoading && <tr><td colSpan={6} className="px-4 py-10 text-center text-ink-500">Loading...</td></tr>}
            {!isLoading && customers.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-10 text-center text-ink-500">No customers yet</td></tr>
            )}
            {customers.map((c: any) => (
              <tr key={c.id} className="hover:bg-ink-50/50 dark:hover:bg-white/5">
                <td className="px-4 py-3 font-semibold">{c.name}</td>
                <td className="px-4 py-3 text-ink-500">{c.username ? `@${c.username}` : c.telegram_id}</td>
                <td className="px-4 py-3 text-ink-500">{c.phone || '—'}</td>
                <td className="px-4 py-3 text-right">{c.orders_count}</td>
                <td className="px-4 py-3 text-right font-bold">{Math.round(Number(c.total_spent))} THB</td>
                <td className="px-4 py-3 text-xs text-ink-500">{c.created_at ? new Date(c.created_at).toLocaleDateString() : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
