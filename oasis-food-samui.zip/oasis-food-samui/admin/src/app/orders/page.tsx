'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ChevronLeft } from 'lucide-react';

import { api, getAdminToken } from '@/lib/api';

const STATUSES = ['pending', 'accepted', 'cooking', 'delivering', 'delivered', 'cancelled'] as const;
type Status = (typeof STATUSES)[number];

const COLOR: Record<Status, string> = {
  pending:    'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  accepted:   'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200',
  cooking:    'bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-200',
  delivering: 'bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-200',
  delivered:  'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  cancelled:  'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200',
};

export default function OrdersAdmin() {
  const router = useRouter();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<Status | 'all'>('all');

  useEffect(() => { if (!getAdminToken()) router.replace('/'); }, [router]);

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['admin-orders', filter],
    queryFn: async () =>
      (await api.get('/admin/orders', { params: filter === 'all' ? {} : { status: filter } })).data,
    refetchInterval: 15_000,
  });

  async function updateStatus(id: number, status: Status) {
    await api.patch(`/admin/orders/${id}/status`, { status });
    qc.invalidateQueries({ queryKey: ['admin-orders'] });
    qc.invalidateQueries({ queryKey: ['stats'] });
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 md:px-8">
      <header className="flex items-center gap-3">
        <Link href="/dashboard" className="grid h-10 w-10 place-items-center rounded-xl border border-ink-200 dark:border-white/15">
          <ChevronLeft size={18} />
        </Link>
        <h1 className="text-3xl font-extrabold tracking-tight">Orders</h1>
      </header>

      <div className="mt-5 flex flex-wrap gap-2">
        {(['all', ...STATUSES] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors ${
              filter === s ? 'bg-ink-900 text-white dark:bg-white dark:text-ink-900' : 'bg-ink-100 text-ink-700 dark:bg-white/10 dark:text-ink-100'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="mt-5 overflow-x-auto rounded-2xl border border-ink-200/60 bg-white shadow-sm dark:border-white/10 dark:bg-white/5">
        <table className="w-full text-sm">
          <thead className="bg-ink-50 text-left text-xs uppercase tracking-wider text-ink-500 dark:bg-white/5">
            <tr>
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3 hidden md:table-cell">Address</th>
              <th className="px-4 py-3 hidden lg:table-cell">Items</th>
              <th className="px-4 py-3 text-right">Total</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-200/60 dark:divide-white/10">
            {isLoading && (
              <tr><td colSpan={7} className="px-4 py-10 text-center text-ink-500">Loading...</td></tr>
            )}
            {!isLoading && orders.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-10 text-center text-ink-500">No orders</td></tr>
            )}
            {orders.map((o: any) => (
              <tr key={o.id} className="hover:bg-ink-50/50 dark:hover:bg-white/5">
                <td className="px-4 py-3 font-mono text-xs">{o.order_number}</td>
                <td className="px-4 py-3">
                  <div className="font-semibold">{o.customer_name}</div>
                  <div className="text-xs text-ink-500">{o.phone}</div>
                </td>
                <td className="px-4 py-3 hidden max-w-xs truncate md:table-cell">{o.address}</td>
                <td className="px-4 py-3 hidden text-xs lg:table-cell">
                  {o.items.map((it: any) => `${it.dish_name}×${it.quantity}`).join(' · ')}
                </td>
                <td className="px-4 py-3 text-right font-bold">{Math.round(Number(o.total_price))} THB</td>
                <td className="px-4 py-3">
                  <span className={`inline-block rounded-full px-2.5 py-1 text-[11px] font-semibold ${COLOR[o.status as Status]}`}>
                    {o.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <select
                    value={o.status}
                    onChange={(e) => updateStatus(o.id, e.target.value as Status)}
                    className="rounded-lg border border-ink-200 bg-white px-2 py-1 text-xs dark:border-white/15 dark:bg-white/10"
                  >
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
