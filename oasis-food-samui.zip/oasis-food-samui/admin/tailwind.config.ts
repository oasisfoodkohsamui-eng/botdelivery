import type { Config } from 'tailwindcss';
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['ui-sans-serif', 'system-ui'] },
      colors: {
        ink: { 50: '#f8fafc', 100: '#f1f5f9', 200: '#e2e8f0', 500: '#64748b', 700: '#334155', 900: '#0f172a' },
        brand: { 500: '#ff7a14', 600: '#f05e08' },
      },
    },
  },
  plugins: [],
};
export default config;
