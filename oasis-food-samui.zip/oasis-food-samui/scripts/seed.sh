#!/usr/bin/env bash
# Seed the database with categories and dishes.
# Usage: ./scripts/seed.sh
set -euo pipefail

cd "$(dirname "$0")/.."

if [ -f .env ]; then
  set -a; . ./.env; set +a
fi

echo "→ Running migrations"
docker compose run --rm backend alembic upgrade head

echo "→ Seeding data"
docker compose run --rm backend python seed.py

echo "✓ Done"
