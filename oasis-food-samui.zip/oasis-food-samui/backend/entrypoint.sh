#!/usr/bin/env bash
# Entry point for the backend container.
# - Runs migrations
# - Seeds the menu on first deploy (idempotent — safe to re-run)
# - Starts uvicorn on Railway's $PORT (or 8000 locally)
set -e

echo "▶ Running migrations..."
alembic upgrade head

if [ "${SEED_ON_START:-true}" = "true" ]; then
  echo "▶ Seeding database (idempotent)..."
  python seed.py || echo "⚠ Seed failed (continuing) — set SEED_ON_START=false to disable"
fi

PORT="${PORT:-8000}"
echo "▶ Starting uvicorn on :$PORT"
exec uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --proxy-headers --forwarded-allow-ips='*'
