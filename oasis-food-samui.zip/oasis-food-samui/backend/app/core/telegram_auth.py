"""Validate Telegram Web App initData using HMAC-SHA256.

Reference: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""
import hashlib
import hmac
import json
import time
from typing import Optional
from urllib.parse import parse_qsl

from app.core.config import settings

# Max age of initData in seconds (24 hours). Anything older is rejected.
MAX_INITDATA_AGE_SECONDS = 86400


def _build_data_check_string(parsed: dict[str, str]) -> str:
    """Build the data-check string per Telegram spec (alphabetically sorted)."""
    items = sorted(
        (f"{k}={v}" for k, v in parsed.items() if k != "hash"),
    )
    return "\n".join(items)


def _secret_key(bot_token: str) -> bytes:
    """Derive secret key for HMAC: HMAC_SHA256(bot_token, key='WebAppData')."""
    return hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()


def validate_init_data(init_data: str, bot_token: Optional[str] = None) -> Optional[dict]:
    """Validate raw initData string. Returns parsed user dict on success, None on failure.

    Returns dict with keys: id, first_name, last_name, username, language_code, ...
    """
    if not init_data:
        return None

    bot_token = bot_token or settings.BOT_TOKEN
    if not bot_token:
        return None

    parsed = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=False))
    received_hash = parsed.get("hash")
    if not received_hash:
        return None

    # Check freshness
    auth_date_str = parsed.get("auth_date")
    if not auth_date_str:
        return None
    try:
        auth_date = int(auth_date_str)
    except ValueError:
        return None
    if time.time() - auth_date > MAX_INITDATA_AGE_SECONDS:
        return None

    # Validate signature
    data_check_string = _build_data_check_string(parsed)
    secret = _secret_key(bot_token)
    expected = hmac.new(secret, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received_hash):
        return None

    user_raw = parsed.get("user")
    if not user_raw:
        return None
    try:
        user = json.loads(user_raw)
    except json.JSONDecodeError:
        return None

    return {
        "user": user,
        "auth_date": auth_date,
        "query_id": parsed.get("query_id"),
        "start_param": parsed.get("start_param"),
    }
