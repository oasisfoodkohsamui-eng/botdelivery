"""Redis cache wrapper with graceful fallback."""
import json
from typing import Any, Optional

import redis.asyncio as aioredis
from loguru import logger

from app.core.config import settings

_redis_client: Optional[aioredis.Redis] = None


async def get_redis() -> Optional[aioredis.Redis]:
    global _redis_client
    if _redis_client is not None:
        return _redis_client
    try:
        _redis_client = aioredis.from_url(
            settings.REDIS_URL, encoding="utf-8", decode_responses=True
        )
        await _redis_client.ping()
        logger.info("Connected to Redis")
        return _redis_client
    except Exception as e:
        logger.warning(f"Redis unavailable, running without cache: {e}")
        _redis_client = None
        return None


async def cache_get(key: str) -> Any:
    r = await get_redis()
    if not r:
        return None
    try:
        v = await r.get(key)
        return json.loads(v) if v else None
    except Exception:
        return None


async def cache_set(key: str, value: Any, ttl: int | None = None) -> None:
    r = await get_redis()
    if not r:
        return
    try:
        await r.set(key, json.dumps(value, default=str), ex=ttl or settings.CACHE_TTL_SECONDS)
    except Exception:
        pass


async def cache_invalidate(pattern: str) -> None:
    r = await get_redis()
    if not r:
        return
    try:
        async for key in r.scan_iter(match=pattern):
            await r.delete(key)
    except Exception:
        pass
