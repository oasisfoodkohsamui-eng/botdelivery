"""Helpers to pick the right translation from a list."""
from typing import Iterable, Optional

from app.core.config import settings


def pick_translation(translations: Iterable, lang: str, fallback: Optional[str] = None):
    """Return the translation row matching lang, or fallback to default language."""
    fallback = fallback or settings.DEFAULT_LANGUAGE
    by_lang = {t.lang: t for t in translations}
    return by_lang.get(lang) or by_lang.get(fallback) or next(iter(by_lang.values()), None)
