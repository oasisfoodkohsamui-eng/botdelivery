"""Send Telegram notifications to admins and customers via Bot API."""
from typing import Optional

import httpx
from loguru import logger

from app.core.config import settings
from app.models import Order, User

TG_API = "https://api.telegram.org"


# Translated status labels (also used by bot)
STATUS_LABELS = {
    "en": {
        "pending": "⏳ Pending",
        "accepted": "✅ Accepted",
        "cooking": "👨‍🍳 Cooking",
        "delivering": "🛵 On the way",
        "delivered": "📦 Delivered",
        "cancelled": "❌ Cancelled",
    },
    "uk": {
        "pending": "⏳ Очікує",
        "accepted": "✅ Прийнято",
        "cooking": "👨‍🍳 Готується",
        "delivering": "🛵 В дорозі",
        "delivered": "📦 Доставлено",
        "cancelled": "❌ Скасовано",
    },
    "ru": {
        "pending": "⏳ Ожидает",
        "accepted": "✅ Принят",
        "cooking": "👨‍🍳 Готовится",
        "delivering": "🛵 В пути",
        "delivered": "📦 Доставлен",
        "cancelled": "❌ Отменён",
    },
}

STATUS_MSGS = {
    "en": "Your order {n} status: {s}",
    "uk": "Статус вашого замовлення {n}: {s}",
    "ru": "Статус вашего заказа {n}: {s}",
}


async def _send(chat_id: int, text: str, parse_mode: str = "HTML") -> None:
    if not settings.BOT_TOKEN:
        return
    url = f"{TG_API}/bot{settings.BOT_TOKEN}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                url,
                json={
                    "chat_id": chat_id,
                    "text": text,
                    "parse_mode": parse_mode,
                    "disable_web_page_preview": True,
                },
            )
            if r.status_code >= 400:
                logger.warning(f"Telegram send failed {r.status_code}: {r.text}")
    except Exception as e:
        logger.warning(f"Telegram send exception: {e}")


async def notify_admin_new_order(order: Order, user: User) -> None:
    if not settings.admin_id_list:
        return
    items_text = "\n".join(f"• {it.dish_name} × {it.quantity} = {it.price * it.quantity:.0f} {order.currency}" for it in order.items)
    text = (
        f"🆕 <b>New order {order.order_number}</b>\n\n"
        f"👤 {order.customer_name}\n"
        f"📞 {order.phone}\n"
        f"📍 {order.address}\n"
    )
    if order.comment:
        text += f"💬 {order.comment}\n"
    text += f"\n{items_text}\n\n"
    text += f"💰 <b>Total: {float(order.total_price):.0f} {order.currency}</b>\n"
    text += f"🌐 Lang: {order.language} | TG: @{user.username or user.telegram_id}"
    for admin_id in settings.admin_id_list:
        await _send(admin_id, text)


async def notify_user_status_change(order: Order, user: User) -> None:
    lang = (order.language or user.language or "en").lower()
    if lang not in STATUS_MSGS:
        lang = "en"
    label = STATUS_LABELS[lang].get(order.status.value, order.status.value)
    text = STATUS_MSGS[lang].format(n=f"<b>{order.order_number}</b>", s=label)
    await _send(user.telegram_id, text)
