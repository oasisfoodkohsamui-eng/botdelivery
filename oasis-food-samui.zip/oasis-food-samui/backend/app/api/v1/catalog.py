"""Public catalog endpoints (categories & dishes)."""
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_language
from app.core.cache import cache_get, cache_set
from app.core.database import get_db
from app.models import Category, Dish
from app.schemas import CategoryOut, DishDetailOut, DishOut
from app.utils.i18n import pick_translation

router = APIRouter(tags=["catalog"])


@router.get("/categories", response_model=List[CategoryOut])
async def list_categories(
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    cache_key = f"cats:{lang}"
    cached = await cache_get(cache_key)
    if cached:
        return cached

    res = await db.execute(
        select(Category)
        .options(selectinload(Category.translations))
        .where(Category.active.is_(True))
        .order_by(Category.sort_order, Category.id)
    )
    out = []
    for c in res.scalars().all():
        t = pick_translation(c.translations, lang)
        out.append(
            CategoryOut(
                id=c.id,
                slug=c.slug,
                icon=c.icon,
                title=t.title if t else c.slug,
                sort_order=c.sort_order,
            ).model_dump()
        )
    await cache_set(cache_key, out, ttl=120)
    return out


def _dish_to_out(dish: Dish, lang: str) -> dict:
    t = pick_translation(dish.translations, lang)
    return {
        "id": dish.id,
        "slug": dish.slug,
        "category_id": dish.category_id,
        "category_slug": dish.category.slug if dish.category else "",
        "image_url": dish.image_url,
        "price": float(dish.price),
        "currency": dish.currency,
        "weight_grams": dish.weight_grams,
        "name": t.name if t else dish.slug,
        "description": t.description if t else None,
        "ingredients": t.ingredients if t else None,
        "featured": dish.featured,
    }


@router.get("/dishes", response_model=List[DishOut])
async def list_dishes(
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
    category: Optional[str] = Query(None, description="Category slug"),
    featured: Optional[bool] = None,
    search: Optional[str] = Query(None, max_length=128),
    limit: int = Query(100, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    cache_key = f"dishes:{lang}:{category}:{featured}:{search}:{limit}:{offset}"
    cached = await cache_get(cache_key)
    if cached:
        return cached

    q = (
        select(Dish)
        .options(selectinload(Dish.translations), selectinload(Dish.category))
        .where(Dish.active.is_(True))
    )
    if category:
        q = q.join(Category).where(Category.slug == category)
    if featured is not None:
        q = q.where(Dish.featured.is_(featured))
    q = q.order_by(Dish.sort_order, Dish.id).limit(limit).offset(offset)

    res = await db.execute(q)
    dishes = res.scalars().all()
    out = [_dish_to_out(d, lang) for d in dishes]
    if search:
        s = search.lower()
        out = [d for d in out if s in (d["name"] or "").lower() or s in (d["description"] or "").lower()]
    await cache_set(cache_key, out, ttl=60)
    return out


@router.get("/dishes/{dish_id}", response_model=DishDetailOut)
async def dish_detail(
    dish_id: int,
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    res = await db.execute(
        select(Dish)
        .options(selectinload(Dish.translations), selectinload(Dish.category))
        .where(Dish.id == dish_id, Dish.active.is_(True))
    )
    dish = res.scalar_one_or_none()
    if not dish:
        raise HTTPException(status_code=404, detail="Dish not found")

    related_res = await db.execute(
        select(Dish)
        .options(selectinload(Dish.translations), selectinload(Dish.category))
        .where(
            Dish.category_id == dish.category_id,
            Dish.id != dish.id,
            Dish.active.is_(True),
        )
        .limit(4)
    )
    related = [_dish_to_out(d, lang) for d in related_res.scalars().all()]
    data = _dish_to_out(dish, lang)
    data["related"] = related
    return data
