"""Order endpoints: checkout, list, get, status."""
from datetime import datetime, timezone
from decimal import Decimal
from secrets import token_hex
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_current_user, get_language
from app.core.database import get_db
from app.models import Cart, CartItem, Dish, Order, OrderItem, OrderStatus, User
from app.schemas import CheckoutRequest, OrderOut
from app.services.notifications import notify_admin_new_order
from app.utils.i18n import pick_translation

router = APIRouter(prefix="/orders", tags=["orders"])


def _generate_order_number() -> str:
    return f"OFS-{datetime.now(timezone.utc).strftime('%y%m%d')}-{token_hex(3).upper()}"


@router.post("/checkout", response_model=OrderOut)
async def checkout(
    payload: CheckoutRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    # Load cart with dishes and translations
    cart_res = await db.execute(
        select(Cart)
        .options(selectinload(Cart.items).selectinload(CartItem.dish).selectinload(Dish.translations))
        .where(Cart.user_id == user.id)
    )
    cart = cart_res.scalar_one_or_none()
    if not cart or not cart.items:
        raise HTTPException(400, "Cart is empty")

    use_lang = (payload.language or user.language or lang).lower()
    total = Decimal("0")
    order_items: list[OrderItem] = []
    for it in cart.items:
        if not it.dish or not it.dish.active:
            continue
        t = pick_translation(it.dish.translations, use_lang)
        line_price = it.dish.price
        total += line_price * it.quantity
        order_items.append(
            OrderItem(
                dish_id=it.dish_id,
                dish_name=t.name if t else it.dish.slug,
                quantity=it.quantity,
                price=line_price,
            )
        )

    if not order_items:
        raise HTTPException(400, "All cart items unavailable")

    order = Order(
        user_id=user.id,
        order_number=_generate_order_number(),
        status=OrderStatus.PENDING,
        total_price=total,
        customer_name=payload.name,
        phone=payload.phone,
        address=payload.address,
        comment=payload.comment,
        language=use_lang,
        items=order_items,
    )
    db.add(order)

    # update user contact info
    user.name = payload.name
    user.phone = payload.phone
    if use_lang in ("en", "uk", "ru"):
        user.language = use_lang

    # clear cart
    for item in list(cart.items):
        await db.delete(item)

    await db.commit()
    await db.refresh(order)

    # fire-and-forget admin notification
    await notify_admin_new_order(order, user)

    # reload with items
    res = await db.execute(
        select(Order).options(selectinload(Order.items)).where(Order.id == order.id)
    )
    return res.scalar_one()


@router.get("", response_model=List[OrderOut])
async def list_my_orders(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    res = await db.execute(
        select(Order)
        .options(selectinload(Order.items))
        .where(Order.user_id == user.id)
        .order_by(Order.created_at.desc())
        .limit(50)
    )
    return res.scalars().all()


@router.get("/{order_id}", response_model=OrderOut)
async def get_order(
    order_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    res = await db.execute(
        select(Order)
        .options(selectinload(Order.items))
        .where(Order.id == order_id, Order.user_id == user.id)
    )
    order = res.scalar_one_or_none()
    if not order:
        raise HTTPException(404, "Order not found")
    return order
