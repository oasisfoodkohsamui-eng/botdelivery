"""Admin endpoints: orders management & analytics."""
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_current_admin
from app.core.database import get_db
from app.models import Order, OrderItem, OrderStatus, User
from app.schemas import AdminStats, OrderOut, OrderStatusUpdate
from app.services.notifications import notify_user_status_change

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/stats", response_model=AdminStats)
async def admin_stats(_: User = Depends(get_current_admin), db: AsyncSession = Depends(get_db)):
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    orders_today = (
        await db.execute(select(func.count(Order.id)).where(Order.created_at >= today_start))
    ).scalar_one() or 0
    orders_total = (await db.execute(select(func.count(Order.id)))).scalar_one() or 0
    revenue_today = (
        await db.execute(
            select(func.coalesce(func.sum(Order.total_price), 0)).where(
                Order.created_at >= today_start,
                Order.status != OrderStatus.CANCELLED,
            )
        )
    ).scalar_one() or Decimal("0")
    revenue_total = (
        await db.execute(
            select(func.coalesce(func.sum(Order.total_price), 0)).where(
                Order.status != OrderStatus.CANCELLED
            )
        )
    ).scalar_one() or Decimal("0")
    pending = (
        await db.execute(
            select(func.count(Order.id)).where(Order.status == OrderStatus.PENDING)
        )
    ).scalar_one() or 0

    top_q = (
        select(
            OrderItem.dish_id,
            OrderItem.dish_name,
            func.sum(OrderItem.quantity).label("qty"),
        )
        .group_by(OrderItem.dish_id, OrderItem.dish_name)
        .order_by(desc("qty"))
        .limit(5)
    )
    top_rows = (await db.execute(top_q)).all()
    top_dishes = [
        {"dish_id": r.dish_id, "name": r.dish_name, "quantity": int(r.qty)} for r in top_rows
    ]

    return AdminStats(
        orders_today=orders_today,
        orders_total=orders_total,
        revenue_today=revenue_today,
        revenue_total=revenue_total,
        pending_orders=pending,
        top_dishes=top_dishes,
    )


@router.get("/orders", response_model=List[OrderOut])
async def admin_list_orders(
    status: Optional[OrderStatus] = None,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    _: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    q = select(Order).options(selectinload(Order.items)).order_by(Order.created_at.desc())
    if status:
        q = q.where(Order.status == status)
    q = q.limit(limit).offset(offset)
    res = await db.execute(q)
    return res.scalars().all()


@router.patch("/orders/{order_id}/status", response_model=OrderOut)
async def admin_update_status(
    order_id: int,
    payload: OrderStatusUpdate,
    _: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    res = await db.execute(
        select(Order).options(selectinload(Order.items)).where(Order.id == order_id)
    )
    order = res.scalar_one_or_none()
    if not order:
        raise HTTPException(404, "Order not found")
    order.status = payload.status
    await db.commit()
    await db.refresh(order)

    # notify user
    user_res = await db.execute(select(User).where(User.id == order.user_id))
    user = user_res.scalar_one_or_none()
    if user:
        await notify_user_status_change(order, user)
    return order


@router.get("/revenue-chart")
async def revenue_chart(
    days: int = Query(7, ge=1, le=90),
    _: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Daily revenue for the past N days."""
    start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days - 1)
    q = (
        select(
            func.date(Order.created_at).label("day"),
            func.coalesce(func.sum(Order.total_price), 0).label("revenue"),
            func.count(Order.id).label("orders"),
        )
        .where(Order.created_at >= start, Order.status != OrderStatus.CANCELLED)
        .group_by("day")
        .order_by("day")
    )
    rows = (await db.execute(q)).all()
    return [
        {"date": str(r.day), "revenue": float(r.revenue), "orders": int(r.orders)} for r in rows
    ]


@router.get("/customers")
async def admin_customers(
    limit: int = Query(100, ge=1, le=500),
    _: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    q = (
        select(
            User.id,
            User.telegram_id,
            User.first_name,
            User.last_name,
            User.username,
            User.phone,
            User.created_at,
            func.count(Order.id).label("orders_count"),
            func.coalesce(func.sum(Order.total_price), 0).label("total_spent"),
        )
        .outerjoin(Order, Order.user_id == User.id)
        .group_by(User.id)
        .order_by(desc("total_spent"))
        .limit(limit)
    )
    rows = (await db.execute(q)).all()
    return [
        {
            "id": r.id,
            "telegram_id": r.telegram_id,
            "name": " ".join(filter(None, [r.first_name, r.last_name])) or r.username or "—",
            "username": r.username,
            "phone": r.phone,
            "orders_count": int(r.orders_count),
            "total_spent": float(r.total_spent),
            "created_at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in rows
    ]
