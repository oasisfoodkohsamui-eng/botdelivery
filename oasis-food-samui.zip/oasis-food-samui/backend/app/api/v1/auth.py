"""Authentication via Telegram Mini App initData."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.core.security import create_access_token
from app.core.telegram_auth import validate_init_data
from app.models import Cart, User
from app.schemas import TelegramAuthRequest, TokenResponse, UserOut

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/telegram", response_model=TokenResponse)
async def auth_telegram(payload: TelegramAuthRequest, db: AsyncSession = Depends(get_db)):
    """Validate Telegram initData, upsert user, return JWT."""
    data = validate_init_data(payload.init_data)
    if not data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Telegram initData"
        )

    tg_user = data["user"]
    tg_id = int(tg_user["id"])
    lang = (tg_user.get("language_code") or "en").lower()
    if lang not in settings.SUPPORTED_LANGUAGES:
        lang = settings.DEFAULT_LANGUAGE

    res = await db.execute(select(User).where(User.telegram_id == tg_id))
    user = res.scalar_one_or_none()
    if not user:
        user = User(
            telegram_id=tg_id,
            username=tg_user.get("username"),
            first_name=tg_user.get("first_name"),
            last_name=tg_user.get("last_name"),
            language=lang,
            is_admin=tg_id in settings.admin_id_list,
        )
        db.add(user)
        await db.flush()
        # auto-create cart
        cart = Cart(user_id=user.id)
        db.add(cart)
    else:
        # refresh basic fields & admin flag
        user.username = tg_user.get("username") or user.username
        user.first_name = tg_user.get("first_name") or user.first_name
        user.last_name = tg_user.get("last_name") or user.last_name
        if tg_id in settings.admin_id_list:
            user.is_admin = True
    await db.commit()
    await db.refresh(user)

    token = create_access_token(user.id, extra={"tg_id": tg_id, "is_admin": user.is_admin})
    return TokenResponse(access_token=token, user=UserOut.model_validate(user))


@router.get("/me", response_model=UserOut)
async def me(user: User = Depends(get_current_user)):
    return user
