"""Cart endpoints."""
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_current_user, get_language
from app.core.database import get_db
from app.models import Cart, CartItem, Dish, User
from app.schemas import CartItemIn, CartItemUpdate, CartOut
from app.utils.i18n import pick_translation

router = APIRouter(prefix="/cart", tags=["cart"])


async def _get_or_create_cart(db: AsyncSession, user_id: int) -> Cart:
    res = await db.execute(
        select(Cart)
        .options(selectinload(Cart.items).selectinload(CartItem.dish).selectinload(Dish.translations))
        .where(Cart.user_id == user_id)
    )
    cart = res.scalar_one_or_none()
    if cart is None:
        cart = Cart(user_id=user_id)
        db.add(cart)
        await db.commit()
        await db.refresh(cart)
    return cart


def _serialize_cart(cart: Cart, lang: str) -> dict:
    items = []
    total = Decimal("0")
    for item in cart.items:
        if not item.dish:
            continue
        t = pick_translation(item.dish.translations, lang)
        subtotal = item.dish.price * item.quantity
        total += subtotal
        items.append(
            {
                "id": item.id,
                "dish_id": item.dish_id,
                "quantity": item.quantity,
                "name": t.name if t else item.dish.slug,
                "image_url": item.dish.image_url,
                "price": float(item.dish.price),
                "subtotal": float(subtotal),
            }
        )
    return {
        "items": items,
        "total": float(total),
        "items_count": sum(i["quantity"] for i in items),
        "currency": "THB",
    }


@router.get("", response_model=CartOut)
async def get_cart(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    cart = await _get_or_create_cart(db, user.id)
    return _serialize_cart(cart, lang)


@router.post("/add", response_model=CartOut)
async def add_to_cart(
    payload: CartItemIn,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    dish = (
        await db.execute(select(Dish).where(Dish.id == payload.dish_id, Dish.active.is_(True)))
    ).scalar_one_or_none()
    if not dish:
        raise HTTPException(404, "Dish not found")

    cart = await _get_or_create_cart(db, user.id)
    existing = next((i for i in cart.items if i.dish_id == payload.dish_id), None)
    if existing:
        existing.quantity = min(99, existing.quantity + payload.quantity)
    else:
        db.add(CartItem(cart_id=cart.id, dish_id=payload.dish_id, quantity=payload.quantity))
    await db.commit()
    cart = await _get_or_create_cart(db, user.id)
    return _serialize_cart(cart, lang)


@router.patch("/item/{item_id}", response_model=CartOut)
async def update_cart_item(
    item_id: int,
    payload: CartItemUpdate,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    cart = await _get_or_create_cart(db, user.id)
    item = next((i for i in cart.items if i.id == item_id), None)
    if not item:
        raise HTTPException(404, "Item not found")
    if payload.quantity == 0:
        await db.delete(item)
    else:
        item.quantity = payload.quantity
    await db.commit()
    cart = await _get_or_create_cart(db, user.id)
    return _serialize_cart(cart, lang)


@router.delete("/item/{item_id}", response_model=CartOut)
async def remove_cart_item(
    item_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    cart = await _get_or_create_cart(db, user.id)
    item = next((i for i in cart.items if i.id == item_id), None)
    if not item:
        raise HTTPException(404, "Item not found")
    await db.delete(item)
    await db.commit()
    cart = await _get_or_create_cart(db, user.id)
    return _serialize_cart(cart, lang)


@router.delete("", response_model=CartOut)
async def clear_cart(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    lang: str = Depends(get_language),
):
    cart = await _get_or_create_cart(db, user.id)
    for item in list(cart.items):
        await db.delete(item)
    await db.commit()
    cart = await _get_or_create_cart(db, user.id)
    return _serialize_cart(cart, lang)
