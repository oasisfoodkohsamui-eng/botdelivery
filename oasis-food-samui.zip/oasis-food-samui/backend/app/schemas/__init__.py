"""Pydantic schemas for API."""
from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from app.models.order import OrderStatus


# ---- Common ----
class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    environment: str


# ---- Auth ----
class TelegramAuthRequest(BaseModel):
    init_data: str = Field(..., min_length=10)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    telegram_id: int
    username: Optional[str]
    first_name: Optional[str]
    last_name: Optional[str]
    name: Optional[str]
    phone: Optional[str]
    language: str
    is_admin: bool


# ---- Categories ----
class CategoryOut(BaseModel):
    id: int
    slug: str
    icon: Optional[str]
    title: str  # localized
    sort_order: int


# ---- Dishes ----
class DishOut(BaseModel):
    id: int
    slug: str
    category_id: int
    category_slug: str
    image_url: Optional[str]
    price: Decimal
    currency: str
    weight_grams: Optional[int]
    name: str
    description: Optional[str]
    featured: bool


class DishDetailOut(DishOut):
    ingredients: Optional[str]
    related: List["DishOut"] = []


# ---- Cart ----
class CartItemIn(BaseModel):
    dish_id: int
    quantity: int = Field(ge=1, le=99)


class CartItemUpdate(BaseModel):
    quantity: int = Field(ge=0, le=99)  # 0 removes


class CartItemOut(BaseModel):
    id: int
    dish_id: int
    quantity: int
    name: str
    image_url: Optional[str]
    price: Decimal
    subtotal: Decimal


class CartOut(BaseModel):
    items: List[CartItemOut]
    total: Decimal
    items_count: int
    currency: str = "THB"


# ---- Orders ----
class CheckoutRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    phone: str = Field(..., min_length=5, max_length=32)
    address: str = Field(..., min_length=3, max_length=1000)
    comment: Optional[str] = Field(None, max_length=1000)
    language: Optional[str] = None


class OrderItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    dish_id: int
    dish_name: str
    quantity: int
    price: Decimal


class OrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    order_number: str
    status: OrderStatus
    total_price: Decimal
    currency: str
    customer_name: str
    phone: str
    address: str
    comment: Optional[str]
    created_at: datetime
    items: List[OrderItemOut]


class OrderStatusUpdate(BaseModel):
    status: OrderStatus


# ---- Admin ----
class AdminStats(BaseModel):
    orders_today: int
    orders_total: int
    revenue_today: Decimal
    revenue_total: Decimal
    pending_orders: int
    top_dishes: List[dict]


TokenResponse.model_rebuild()
DishDetailOut.model_rebuild()
