"""Category models."""
from typing import Optional

from sqlalchemy import Boolean, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Category(Base):
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    icon: Mapped[Optional[str]] = mapped_column(String(16), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

    translations = relationship(
        "CategoryTranslation", back_populates="category", cascade="all, delete-orphan"
    )
    dishes = relationship("Dish", back_populates="category", cascade="all, delete-orphan")


class CategoryTranslation(Base):
    __tablename__ = "category_translations"
    __table_args__ = (UniqueConstraint("category_id", "lang", name="uq_cat_lang"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="CASCADE"))
    lang: Mapped[str] = mapped_column(String(8), index=True)
    title: Mapped[str] = mapped_column(String(128))

    category = relationship("Category", back_populates="translations")
