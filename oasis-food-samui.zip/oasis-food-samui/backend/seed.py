"""Seed script: populates DB with categories and dishes from JSON files.

Usage:
    python seed.py
"""
import asyncio
import json
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select

from app.core.database import AsyncSessionLocal
from app.models import (
    Category,
    CategoryTranslation,
    Dish,
    DishTranslation,
)

BASE = Path(__file__).parent / "seed_data"


async def seed():
    async with AsyncSessionLocal() as db:
        # Categories
        categories = json.loads((BASE / "categories.json").read_text(encoding="utf-8"))
        cat_map: dict[str, Category] = {}
        for c in categories:
            existing = (
                await db.execute(select(Category).where(Category.slug == c["slug"]))
            ).scalar_one_or_none()
            if existing:
                cat_map[c["slug"]] = existing
                continue
            cat = Category(slug=c["slug"], icon=c.get("icon"), sort_order=c.get("sort_order", 0))
            db.add(cat)
            await db.flush()
            for lang, title in c["translations"].items():
                db.add(CategoryTranslation(category_id=cat.id, lang=lang, title=title))
            cat_map[c["slug"]] = cat
            print(f"+ category {c['slug']}")
        await db.commit()

        # Dishes
        dishes = json.loads((BASE / "dishes.json").read_text(encoding="utf-8"))
        for d in dishes:
            existing = (
                await db.execute(select(Dish).where(Dish.slug == d["slug"]))
            ).scalar_one_or_none()
            if existing:
                continue
            cat = cat_map.get(d["category"])
            if not cat:
                print(f"! unknown category for {d['slug']}")
                continue
            dish = Dish(
                slug=d["slug"],
                category_id=cat.id,
                image_url=d.get("image_url"),
                price=Decimal(str(d["price"])),
                currency=d.get("currency", "THB"),
                weight_grams=d.get("weight_grams"),
                featured=d.get("featured", False),
                sort_order=d.get("sort_order", 0),
            )
            db.add(dish)
            await db.flush()
            for lang, tr in d["translations"].items():
                db.add(
                    DishTranslation(
                        dish_id=dish.id,
                        lang=lang,
                        name=tr["name"],
                        description=tr.get("description"),
                        ingredients=tr.get("ingredients"),
                    )
                )
            print(f"+ dish {d['slug']}")
        await db.commit()
        print("Seed done.")


if __name__ == "__main__":
    asyncio.run(seed())
