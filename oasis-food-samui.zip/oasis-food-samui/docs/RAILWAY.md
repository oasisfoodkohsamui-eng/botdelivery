# 🚂 Деплой на Railway — крок за кроком

Цей гайд проводить тебе від нуля до робочого Telegram Mini App на Railway.
Час: ~15–20 хвилин для першого разу.

## Що ти отримаєш

6 сервісів в одному Railway проекті:

```
┌─ Postgres (плагін)
├─ Redis (плагін)
├─ backend     ← FastAPI API
├─ bot         ← aiogram (long-polling worker)
├─ frontend    ← Telegram Mini App (Next.js)
└─ admin       ← Адмін-панель (Next.js)
```

---

## КРОК 0 — Що потрібно мати під рукою

1. **Bot Token** — у `@BotFather`: `/newbot` → отримай токен типу `7000000000:AAH...`
2. **Twій Telegram ID** — напиши `@userinfobot` → він пришле число типу `123456789`
3. **JWT секрет** — згенеруй у терміналі:
   ```bash
   openssl rand -hex 32
   ```
4. **GitHub репозиторій** — заллий код:
   ```bash
   cd oasis-food-samui
   git init && git add . && git commit -m "init"
   git remote add origin git@github.com:USERNAME/oasis-food-samui.git
   git push -u origin main
   ```
5. **Railway акаунт** — `https://railway.com` → Login with GitHub

---

## КРОК 1 — Створити проект і додати бази

1. На Railway натисни **+ New Project → Empty Project**
2. Назви його `oasis-food-samui`
3. У середині проекту: **+ Create → Database → Add PostgreSQL**
4. Ще раз: **+ Create → Database → Add Redis**

Railway автоматично створить змінні `DATABASE_URL` та `REDIS_URL`, які ми будемо реферити.

---

## КРОК 2 — Деплой Backend (FastAPI)

1. У проекті: **+ Create → GitHub Repo → обрати `oasis-food-samui`**
2. Назви сервіс: **`backend`**
3. Відкрий вкладку **Settings**:
   - **Root Directory** → `backend`
   - **Watch Paths** → `backend/**` (опційно — деплоїть лише при змінах backend)
4. Вкладка **Variables** — додай:

   | Змінна | Значення |
   |--------|----------|
   | `DATABASE_URL` | `${{Postgres.DATABASE_URL}}` |
   | `REDIS_URL` | `${{Redis.REDIS_URL}}` |
   | `JWT_SECRET` | твій згенерований hex |
   | `BOT_TOKEN` | токен з BotFather |
   | `ADMIN_IDS` | твій Telegram ID (через кому, якщо кілька) |
   | `MINI_APP_URL` | `https://placeholder.up.railway.app` (поки що, оновимо) |
   | `CORS_ORIGINS` | `*` (тимчасово, потім звузимо) |
   | `ENVIRONMENT` | `production` |
   | `SEED_ON_START` | `true` |

5. Вкладка **Settings → Networking → Generate Domain** — отримаєш URL типу `backend-production-xxxx.up.railway.app`. **Збережи цей URL — він знадобиться нижче.**

6. Сервіс задеплоїться автоматично. Перевір логи — мають бути:
   ```
   ▶ Running migrations...
   ▶ Seeding database (idempotent)...
   + category ukrainian
   ...
   ▶ Starting uvicorn on :8080
   ```

7. Перевірка: відкрий `https://backend-production-xxxx.up.railway.app/health` → побачиш `{"status": "ok"}`.

---

## КРОК 3 — Деплой Frontend (Mini App)

1. **+ Create → GitHub Repo → той самий репо**
2. Назва: **`frontend`**
3. **Settings → Root Directory → `frontend`**
4. **Variables:**

   | Змінна | Значення |
   |--------|----------|
   | `NEXT_PUBLIC_API_URL` | `https://backend-production-xxxx.up.railway.app` (URL з КРОКУ 2) |

5. **Settings → Networking → Generate Domain** → отримаєш `frontend-production-yyyy.up.railway.app`. **Збережи.**

6. ⏳ Чекай ~3 хвилини, поки Next.js збереться.

7. Перевірка: відкрий URL у звичайному браузері. Має завантажитись головна (з пустим меню — це нормально, бо браузер не Telegram).

---

## КРОК 4 — Оновити Backend з реальними URL

Повертайся у сервіс `backend` → **Variables** → онови дві змінні:

| Змінна | Значення |
|--------|----------|
| `MINI_APP_URL` | `https://frontend-production-yyyy.up.railway.app` |
| `CORS_ORIGINS` | `https://frontend-production-yyyy.up.railway.app,https://admin-production-zzzz.up.railway.app` (admin додамо на КРОЦІ 6) |

Railway перезапустить сервіс автоматично.

---

## КРОК 5 — Деплой Bot

1. **+ Create → GitHub Repo → той самий репо**
2. Назва: **`bot`**
3. **Settings → Root Directory → `bot`**
4. **Variables:**

   | Змінна | Значення |
   |--------|----------|
   | `BOT_TOKEN` | той самий токен |
   | `ADMIN_IDS` | той самий ID |
   | `MINI_APP_URL` | URL frontend з КРОКУ 3 |
   | `API_BASE_URL` | `https://backend-production-xxxx.up.railway.app` |
   | `BOT_USERNAME` | username бота без `@` |
   | `SUPPORT_USERNAME` | (опційно) username для контакту з підтримкою |

5. Сервіс задеплоїться. У логах має бути:
   ```
   Bot started. Awaiting updates...
   ```

6. **Бот НЕ потребує Generate Domain** — він пуллить апдейти через long-polling.

---

## КРОК 6 — Деплой Admin

1. **+ Create → GitHub Repo → той самий репо**
2. Назва: **`admin`**
3. **Settings → Root Directory → `admin`**
4. **Variables:**

   | Змінна | Значення |
   |--------|----------|
   | `NEXT_PUBLIC_API_URL` | URL backend |

5. **Settings → Networking → Generate Domain** → отримаєш `admin-production-zzzz.up.railway.app`.

6. Повернись у `backend` → онови `CORS_ORIGINS` додавши URL адмінки.

---

## КРОК 7 — Підключити Mini App до Telegram

Відкривай `@BotFather` у Telegram:

1. `/mybots` → обери свого бота → **Bot Settings → Menu Button → Configure Menu Button**
   - Text: `🍽 Open App`
   - URL: `https://frontend-production-yyyy.up.railway.app`

2. `/setdomain` → обери бота → введи **тільки домен без https://**:
   ```
   frontend-production-yyyy.up.railway.app
   ```

3. `/newapp` (опційно — потрібно для `t.me/yourbot/app` deep-link):
   - Обери бота
   - Title: `Oasis Food`
   - Description: `Authentic flavors delivered to your door`
   - Photo: завантаж 640×360 зображення
   - Web App URL: той самий URL frontend
   - Short name: `app`

---

## КРОК 8 — Перевірка

1. У Telegram знайди свого бота і натисни **/start**
2. З'явиться повідомлення з кнопкою **🍽 Open Oasis Food App**
3. Тапни кнопку — відкриється Mini App
4. Має автоматично авторизуватись, показатися меню
5. Додай страву → checkout → залиш фейкові ім'я/телефон/адресу → замов
6. Через секунду тобі (як адміну) має прийти в Telegram повідомлення з замовленням 🎉

---

## КРОК 9 — Адмін-панель

1. Відкрий Mini App у Telegram **як адмін** (твій ID має бути в `ADMIN_IDS`)
2. У браузері Telegram-app DevTools (або через сторонній браузер з токеном з `localStorage`) витягни JWT:
   ```js
   localStorage.getItem('token')
   ```
3. Відкрий `https://admin-production-zzzz.up.railway.app`
4. Встав JWT → **Continue**
5. Побачиш дашборд із статистикою, замовленнями, клієнтами

> 💡 У майбутньому можна додати login-by-Telegram через адмін-бота. Поки що paste-token це найпростіший і надійний спосіб для команди з 1–3 людей.

---

## 🛠 Що робити, якщо щось не так

### Backend не стартує

Логи: **backend → Deployments → View Logs**.

Типові помилки:
- `DATABASE_URL is not set` → перевір, що в Variables є `${{Postgres.DATABASE_URL}}`
- `JWT_SECRET is not set` → встав будь-який hex рядок
- `connection refused` → Postgres плагін ще не стартував, почекай 30 сек і **Redeploy**

### Mini App у Telegram показує "white screen"

- Перевір, що `MINI_APP_URL` у BotFather починається з `https://`
- Перевір, що в `/setdomain` ти ввів **тільки домен**, без `https://` і без слешу
- Відкрий URL у Chrome — якщо там 200 ОК, то проблема в Telegram налаштуваннях

### Mini App відкривається, але показує "Invalid Telegram initData"

Це означає, що `BOT_TOKEN` різний у backend і bot сервісах. Перевір, що значення **точно однакове** (без пробілів).

### Бот не реагує на /start

- Перевір логи bot сервісу — має бути `Bot started. Awaiting updates...`
- Якщо бачиш `Unauthorized` — токен невірний
- Якщо тиша, але ти точно щось пишеш боту — може хтось вже запустив того самого бота локально. Зупини всі інші процеси з тим токеном.

### Бот не присилає сповіщення про замовлення

- Перевір, що `ADMIN_IDS` у backend сервісі містить твій числовий ID (а не username)
- Адмін має хоча б раз написати боту /start, інакше Telegram не дозволить боту йому писати

### CORS errors у консолі браузера

Додай домен фронтенду в `CORS_ORIGINS` (через кому, без пробілів):
```
CORS_ORIGINS=https://frontend-production-yyyy.up.railway.app,https://admin-production-zzzz.up.railway.app
```

### Хочу зменшити витрати

- Postgres та Redis на free-tier обмежені — для боку це нормально, але великий трафік швидко зжере 5$ грантів
- Railway бере оплату за **активний час** і пам'ять. Якщо ресторан працює лише вдень — можна налаштувати auto-sleep вночі (Pro план)
- Можна замінити Redis на in-memory кеш у самому FastAPI (видали `REDIS_URL` — код gracefully фолбекне)

---

## 📜 Корисні команди

```bash
# Підключитись через Railway CLI
railway login
railway link                            # обрати проект

# Подивитися логи
railway logs --service backend

# Запустити seed заново (якщо щось пішло не так)
railway run --service backend python seed.py

# Зайти в Postgres
railway connect postgres

# Передеплоїти
railway up --service backend
```

---

## Стрес-тест-чеклист перед запуском для реальних клієнтів

- [ ] `JWT_SECRET` — не дефолтний, мінімум 32 символи рандому
- [ ] `CORS_ORIGINS` — конкретні домени, **не** `*`
- [ ] `ENVIRONMENT=production`, `DEBUG=false`
- [ ] `ADMIN_IDS` — справжні ID, не нулі
- [ ] У BotFather: `/setdescription`, `/setabouttext`, `/setuserpic` — заповнено
- [ ] Тестове замовлення проходить від `/start` до сповіщення адміна
- [ ] Адмін у панелі може змінити статус → клієнт отримує повідомлення
- [ ] Перевір, що seed-data відповідає реальному меню (заміни картинки на свої CDN)
- [ ] Платежі (поки що cash on delivery) — узгоджено з кухнею
- [ ] Доменне ім'я (опційно): **Settings → Custom Domain** замість `*.up.railway.app`
