# Deployment guide

A step-by-step recipe for shipping **Oasis Food Samui** to production on Railway.

## 0 · Prerequisites

- A Telegram bot from **@BotFather** (token in hand)
- Your numeric Telegram ID from **@userinfobot**
- A Railway account (`https://railway.com`) with billing enabled (free tier works for testing)
- A Git remote (GitHub, GitLab…) hosting this repo

## 1 · Spin up Postgres & Redis

In your Railway project:
1. Click **+ New → Database → PostgreSQL**
2. Click **+ New → Database → Redis**

Both services emit `DATABASE_URL` / `REDIS_URL` variables that we'll reference from the backend.

## 2 · Deploy the backend

1. **+ New → GitHub repo → select this repo**
2. Set **Root Directory:** `/` (Railway reads `backend/railway.json`)

   *(Or set Root to `/backend` and remove the path from the `dockerfilePath` field.)*
3. Set environment variables:
   ```
   DATABASE_URL = ${{Postgres.DATABASE_URL}}
   REDIS_URL    = ${{Redis.REDIS_URL}}
   JWT_SECRET   = <openssl rand -hex 32>
   BOT_TOKEN    = <from BotFather>
   ADMIN_IDS    = <your TG id>,<other admin id>
   MINI_APP_URL = https://<frontend-service>.up.railway.app
   CORS_ORIGINS = https://<frontend-service>.up.railway.app,https://<admin-service>.up.railway.app
   ENVIRONMENT  = production
   ```
4. Deploy. Migrations run automatically on startup.

## 3 · Seed the database (one-time)

From your local machine with the Railway CLI:
```bash
railway link
railway run --service backend python seed.py
```

## 4 · Deploy the bot

1. **+ New → GitHub repo → same repo**, point the service at `bot/railway.json`.
2. Variables:
   ```
   BOT_TOKEN     = <same token>
   ADMIN_IDS     = <same admins>
   MINI_APP_URL  = https://<frontend>.up.railway.app
   API_BASE_URL  = http://${{backend.RAILWAY_PRIVATE_DOMAIN}}:8000   # internal
   ```
3. Deploy. Long-polling starts automatically.

## 5 · Deploy the Mini App (frontend)

1. **+ New → GitHub repo**, point at `frontend/railway.json`.
2. Variables:
   ```
   NEXT_PUBLIC_API_URL = https://<backend>.up.railway.app
   ```
3. Deploy. Note the public URL — this is your `MINI_APP_URL`.

## 6 · Deploy the admin panel

1. **+ New → GitHub repo**, point at `admin/railway.json`.
2. Variables:
   ```
   NEXT_PUBLIC_API_URL = https://<backend>.up.railway.app
   ```

## 7 · Wire the Mini App to Telegram

In **@BotFather**:
- `/mybots` → choose your bot → **Bot Settings → Menu Button** → **Configure Menu Button** → URL = `https://<frontend>.up.railway.app`
- `/newapp` → attach the same URL as a Web App (used by inline `WebAppInfo`).
- `/setdomain` → set the frontend domain.

## 8 · First-run check

1. `/start` in your bot → **🍽 Open Oasis Food App** appears.
2. Tap → Mini App loads, language defaults to your Telegram one.
3. Add a dish → checkout → fill in details → place order.
4. Bot DM hits all `ADMIN_IDS` with the order summary.
5. Open `https://<admin>.up.railway.app`, paste the JWT (see admin section in README), change order status → user receives an update from the bot.

## 9 · Operations

- Logs: Railway UI → service → **Logs**
- DB shell: `railway connect postgres`
- Re-seed only fresh categories/dishes: it's idempotent — safe to re-run `python seed.py`
- Roll back: Railway → deployment → **Redeploy** previous build

---

## Local development

```bash
cp .env.example .env
# fill BOT_TOKEN, ADMIN_IDS, JWT_SECRET
docker compose up --build
./scripts/seed.sh
```

For dev without Telegram (no `initData`), the auth endpoint will reject calls. Workaround for hot iteration: temporarily enable a dev-bypass behind `DEBUG=true` and a feature flag in `auth.py`.

---

## Troubleshooting

| Symptom | Fix |
| ------- | --- |
| Mini App white-screens in Telegram | Confirm the URL is **HTTPS** and matches `/setdomain` in BotFather |
| `Invalid Telegram initData` | Ensure the same `BOT_TOKEN` is used by bot and backend |
| 401 on every request | Token expired (7 d) — Mini App re-authenticates automatically; check that `Authorization: Bearer` header is being attached (interceptor) |
| Bot notifications never arrive | `ADMIN_IDS` empty or wrong format (numeric IDs only) |
| CORS errors | Add frontend & admin origins to `CORS_ORIGINS` (comma-separated) |
| `dish.image_url` not loading | The seed uses Unsplash URLs; ensure outbound HTTPS isn't blocked, or swap to your own CDN |
