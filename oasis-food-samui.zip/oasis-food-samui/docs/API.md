# API Reference

All endpoints are versioned under `/api/v1`. Full interactive docs at `/docs` (Swagger UI) when the backend is running.

## Headers

| Header | Purpose |
| ------ | ------- |
| `Authorization: Bearer <jwt>` | Required for every endpoint except `/auth/telegram` and `/health`. |
| `X-Language: en|uk|ru` | Optional. Selects translation language. Falls back to `Accept-Language` and then to the default. |

## Auth

### `POST /auth/telegram`

Exchange validated Telegram `initData` for a JWT.

```json
// request
{ "init_data": "query_id=...&user=...&auth_date=...&hash=..." }

// response
{
  "access_token": "eyJhbGciOi...",
  "token_type": "bearer",
  "user": {
    "id": 1, "telegram_id": 123, "first_name": "...",
    "language": "en", "is_admin": false, ...
  }
}
```

### `GET /auth/me`
Returns the authenticated user.

## Catalog

### `GET /categories`
Returns localized categories sorted by `sort_order`.

### `GET /dishes`
Query: `category` (slug), `featured` (bool), `search` (string), `limit`, `offset`.

### `GET /dishes/{id}`
Returns a single dish with `ingredients` and a `related` array.

## Cart

| Method | Path | Body |
| ------ | ---- | ---- |
| GET    | `/cart` | — |
| POST   | `/cart/add` | `{ dish_id, quantity }` |
| PATCH  | `/cart/item/{id}` | `{ quantity }` (0 deletes) |
| DELETE | `/cart/item/{id}` | — |
| DELETE | `/cart` | clear |

## Orders

### `POST /orders/checkout`
```json
{
  "name": "John Doe",
  "phone": "+66 99 123 4567",
  "address": "Beach Rd 100/12, Lamai",
  "comment": "No spicy, please",
  "language": "en"
}
```
Returns the created `Order` with items.

### `GET /orders`
List the authenticated user's orders (latest 50).

### `GET /orders/{id}`
Returns one order belonging to the authenticated user.

## Admin (requires `is_admin = true` or `telegram_id ∈ ADMIN_IDS`)

| Method | Path | Description |
| ------ | ---- | ----------- |
| GET    | `/admin/stats` | KPIs + top 5 dishes |
| GET    | `/admin/orders` | All orders. `?status=…` |
| PATCH  | `/admin/orders/{id}/status` | `{ status }`; notifies the customer |
| GET    | `/admin/revenue-chart?days=14` | daily revenue & order count |
| GET    | `/admin/customers` | top customers by total spent |

## Order status state machine

```
pending → accepted → cooking → delivering → delivered
   │
   └────► cancelled  (any time)
```
