# 🥘 Oasis Food Samui

A premium **multilingual Telegram Mini App** food-delivery platform for the Oasis Food Samui restaurant on Koh Samui — featuring a Telegram bot, a Next.js 14 mobile-first Mini App, a FastAPI backend, a PostgreSQL database, an admin dashboard, and full Docker / Railway deployment.

> Modern food-delivery UX (Uber Eats / Glovo feel) — inside Telegram.

---

## ✨ Features

| Area | What you get |
| ---- | ------------ |
| **Telegram Bot** | aiogram 3.x · `/start` launches Mini App · admin notifications · language switcher (EN/UK/RU) |
| **Mini App** | Next.js 14, TypeScript, TailwindCSS, Framer Motion, React Query, Zustand · Telegram theme + haptics · dark/light · safe-area aware |
| **Backend** | FastAPI · async SQLAlchemy 2 · Alembic · Pydantic v2 · JWT · Redis cache · rate-limited · validates Telegram `initData` HMAC |
| **Database** | PostgreSQL with per-language translation tables (no hardcoded strings) |
| **Admin** | Live dashboard · order management · revenue chart · top dishes · customer list |
| **i18n** | 🇬🇧 English · 🇺🇦 Українська · 🇷🇺 Русский — bot, frontend, and DB content |
| **DevOps** | Dockerfile per service · `docker-compose.yml` for local dev · `railway.json` per service for one-click deploys |

---

## 🏗 Architecture

```
                    ┌─────────────────┐
   Telegram user ──►│  Telegram Bot   │  aiogram (long polling)
                    │   (Python)      │
                    └────────┬────────┘
                             │  HTTPS WebApp launch
                             ▼
                    ┌─────────────────┐         ┌──────────────┐
                    │  Mini App       │ ◄────►  │  Backend API │
                    │  Next.js 14     │  JSON   │   FastAPI    │
                    └─────────────────┘         └──────┬───────┘
                             ▲                         │
                             │                  ┌──────┴──────┐
                    ┌────────┴────────┐         ▼             ▼
                    │   Admin Panel   │   PostgreSQL       Redis
                    │   Next.js       │   (translations,   (cache)
                    └─────────────────┘    orders, users)
```

---

## 📂 Project Structure

```
oasis-food-samui/
├── backend/            FastAPI app + SQLAlchemy + Alembic + seed data
│   ├── app/
│   │   ├── api/v1/     route modules (auth, catalog, cart, orders, admin)
│   │   ├── core/       config, db, security, telegram_auth, cache
│   │   ├── models/     ORM models
│   │   ├── schemas/    pydantic schemas
│   │   ├── services/   notifications etc.
│   │   └── main.py     FastAPI entry
│   ├── alembic/        migrations (0001_init.py)
│   ├── seed_data/      categories.json + dishes.json (EN/UK/RU)
│   ├── seed.py
│   ├── Dockerfile · railway.json · Procfile · requirements.txt
│
├── bot/                aiogram 3.x bot
│   ├── handlers/       user.py · admin.py
│   ├── keyboards/      WebApp launcher · language picker
│   ├── locales/        EN / UK / RU dictionaries
│   ├── main.py · config.py · Dockerfile · railway.json
│
├── frontend/           Next.js 14 Mini App (App Router)
│   ├── src/app/        page.tsx (home), menu, dish/[id], cart, checkout, order/[id], orders
│   ├── src/components/ TopBar · BottomNav · DishCard · CategoryChips · FloatingCart …
│   ├── src/i18n/       React i18n + en/uk/ru JSON locales
│   ├── src/lib/        api · telegram · utils
│   ├── src/store/      Zustand stores (auth, cart)
│   ├── Dockerfile · railway.json · tailwind.config.ts
│
├── admin/              Next.js admin dashboard
│   ├── src/app/        login · dashboard · orders · customers
│   └── Dockerfile · railway.json
│
├── docker-compose.yml
├── .env.example
└── scripts/seed.sh
```

---

## 🚀 Quick Start (Docker)

```bash
# 1. Clone & enter
git clone <your-repo> oasis-food-samui && cd oasis-food-samui

# 2. Configure
cp .env.example .env
#   ┗━ fill in BOT_TOKEN, ADMIN_IDS, JWT_SECRET

# 3. Boot everything
docker compose up --build

# 4. Seed the menu (run once)
./scripts/seed.sh
```

Then:
- Backend API → http://localhost:8000  (Swagger docs at `/docs`)
- Mini App    → http://localhost:3000
- Admin       → http://localhost:3001

To test the Mini App inside Telegram, expose port 3000 over HTTPS — see **Production Deploy** below.

---

## 🤖 Bot setup

1. Create the bot in **@BotFather** → `/newbot` → copy the token into `BOT_TOKEN`.
2. **@BotFather** → `/setdomain` → set your Mini App domain (Railway URL or custom).
3. **@BotFather** → `/newapp` → attach the Web App URL.
4. Get your Telegram numeric ID via **@userinfobot** → add it to `ADMIN_IDS`.

Now `/start` opens the Mini App and new orders ping every admin in `ADMIN_IDS`.

---

## 🚂 Deploying to Railway

Each of the four services has its own `railway.json`. Create the project, then add four services pointing to the same repo:

| Service  | Root              | Dockerfile          | Required variables |
| -------- | ----------------- | ------------------- | ------------------ |
| postgres | (Railway plugin)  | —                   | auto-provisioned `DATABASE_URL` |
| redis    | (Railway plugin)  | —                   | auto-provisioned `REDIS_URL`    |
| backend  | `/backend`        | `backend/Dockerfile`| `DATABASE_URL`, `REDIS_URL`, `JWT_SECRET`, `BOT_TOKEN`, `ADMIN_IDS`, `MINI_APP_URL`, `CORS_ORIGINS` |
| bot      | `/bot`            | `bot/Dockerfile`    | `BOT_TOKEN`, `ADMIN_IDS`, `MINI_APP_URL`, `API_BASE_URL` (= backend internal URL) |
| frontend | `/frontend`       | `frontend/Dockerfile` | `NEXT_PUBLIC_API_URL` (= backend public URL) |
| admin    | `/admin`          | `admin/Dockerfile`  | `NEXT_PUBLIC_API_URL` |

**Important:** put real public HTTPS URLs in `MINI_APP_URL` and `NEXT_PUBLIC_API_URL` — Telegram only loads HTTPS Mini Apps.

Run migrations + seed once after first deploy:
```bash
railway run --service backend python seed.py
```

---

## 🔐 Security

- Telegram `initData` is verified with HMAC-SHA256 against the bot token (`core/telegram_auth.py`).
- All authenticated endpoints require a JWT issued only after `initData` validation.
- Admins are determined by Telegram ID being present in `ADMIN_IDS` **or** by the DB flag `is_admin`.
- Rate-limited (default 60 req/min/IP) via `slowapi`.
- Configurable CORS via `CORS_ORIGINS`.
- All secrets exclusively from environment variables — never hardcoded.

---

## 🌐 i18n

- **Backend:** `lang` is taken from `X-Language` header (or `Accept-Language`). Dish/category content is stored in dedicated translation tables. `pick_translation()` falls back to the default language when a translation is missing.
- **Frontend:** static UI strings live in `src/i18n/locales/{en,uk,ru}.json`. A React context (`useI18n`) renders the right language and persists user preference in `localStorage`. The Telegram user's `language_code` is auto-detected at first launch.
- **Bot:** `bot/locales/__init__.py` — dictionary lookup with a `t(key, lang)` helper.

Add a new language in three steps:
1. Add a JSON file in `frontend/src/i18n/locales/`.
2. Add the language code to `SUPPORTED_LANGUAGES` in `backend/app/core/config.py`.
3. Add bot translations to `bot/locales/__init__.py`.

---

## 🧩 Extending

The architecture is intentionally easy to grow:

- **Payments** — add a `payments` module under `backend/app/services/` (Stripe / Telegram Payments) and a new step before `OrderStatus.ACCEPTED`.
- **Promo codes** — add a `promotions` model with `apply()` hook in `checkout`.
- **Push** — already in place via Bot API (`services/notifications.py`).
- **Maps / courier tracking** — add `latitude`/`longitude` to `Order`, embed a Mapbox/Google component in the order page.
- **CRM / Google Sheets** — webhook on order create in `orders.py`.

---

## 📜 License

MIT — do whatever helps your restaurant.
