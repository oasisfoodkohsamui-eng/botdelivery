"""Bot entrypoint (aiogram 3.x, long polling)."""
import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand
from loguru import logger

from bot.config import settings
from bot.handlers import admin as admin_handlers
from bot.handlers import user as user_handlers


async def set_bot_commands(bot: Bot):
    """Set commands shown in the Telegram UI."""
    commands = [
        BotCommand(command="start", description="Open the app"),
        BotCommand(command="menu", description="Browse menu"),
        BotCommand(command="orders", description="My orders"),
        BotCommand(command="lang", description="Change language"),
        BotCommand(command="help", description="Help"),
    ]
    await bot.set_my_commands(commands)


async def main() -> None:
    if not settings.BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is not set")

    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()
    dp.include_router(admin_handlers.router)
    dp.include_router(user_handlers.router)

    await set_bot_commands(bot)
    logger.info("Bot started. Awaiting updates...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
