"""Simple bot i18n (no external lib — keeps the bot light)."""
from typing import Optional

LOCALES = {
    "en": {
        "welcome": (
            "👋 Welcome to <b>Oasis Food Samui</b>!\n\n"
            "🥘 Authentic flavors delivered to your door on Koh Samui.\n"
            "Tap the button below to browse the menu and place your order."
        ),
        "open_app": "🍽 Open Oasis Food App",
        "menu": "📖 Menu",
        "orders": "📦 My orders",
        "support": "🆘 Support",
        "language": "🌐 Language",
        "help": (
            "ℹ️ <b>Commands</b>\n"
            "/start — open the app\n"
            "/menu — browse menu\n"
            "/orders — your orders\n"
            "/lang — change language\n"
            "/help — this help"
        ),
        "choose_language": "Choose your language:",
        "language_set": "Language set to English ✅",
        "support_text": "📞 Need help? Write to {support} or call us.",
        "admin_only": "Admin only.",
        "admin_panel": "👑 Admin panel",
        "admin_help": (
            "👑 <b>Admin commands</b>\n"
            "/admin — admin panel\n"
            "/stats — quick stats\n"
            "/pending — pending orders"
        ),
    },
    "uk": {
        "welcome": (
            "👋 Ласкаво просимо до <b>Oasis Food Samui</b>!\n\n"
            "🥘 Справжні смаки з доставкою на Самуї.\n"
            "Натисніть кнопку нижче, щоб переглянути меню та оформити замовлення."
        ),
        "open_app": "🍽 Відкрити Oasis Food App",
        "menu": "📖 Меню",
        "orders": "📦 Мої замовлення",
        "support": "🆘 Підтримка",
        "language": "🌐 Мова",
        "help": (
            "ℹ️ <b>Команди</b>\n"
            "/start — відкрити застосунок\n"
            "/menu — переглянути меню\n"
            "/orders — мої замовлення\n"
            "/lang — змінити мову\n"
            "/help — допомога"
        ),
        "choose_language": "Оберіть мову:",
        "language_set": "Мову встановлено: Українська ✅",
        "support_text": "📞 Потрібна допомога? Напишіть {support} або зателефонуйте.",
        "admin_only": "Лише для адміністратора.",
        "admin_panel": "👑 Адмін-панель",
        "admin_help": (
            "👑 <b>Команди адміна</b>\n"
            "/admin — адмін-панель\n"
            "/stats — статистика\n"
            "/pending — нові замовлення"
        ),
    },
    "ru": {
        "welcome": (
            "👋 Добро пожаловать в <b>Oasis Food Samui</b>!\n\n"
            "🥘 Настоящие вкусы с доставкой на Самуи.\n"
            "Нажмите кнопку ниже, чтобы открыть меню и оформить заказ."
        ),
        "open_app": "🍽 Открыть Oasis Food App",
        "menu": "📖 Меню",
        "orders": "📦 Мои заказы",
        "support": "🆘 Поддержка",
        "language": "🌐 Язык",
        "help": (
            "ℹ️ <b>Команды</b>\n"
            "/start — открыть приложение\n"
            "/menu — меню\n"
            "/orders — мои заказы\n"
            "/lang — сменить язык\n"
            "/help — помощь"
        ),
        "choose_language": "Выберите язык:",
        "language_set": "Язык установлен: Русский ✅",
        "support_text": "📞 Нужна помощь? Напишите {support} или позвоните.",
        "admin_only": "Только для администратора.",
        "admin_panel": "👑 Админ-панель",
        "admin_help": (
            "👑 <b>Команды админа</b>\n"
            "/admin — админ-панель\n"
            "/stats — статистика\n"
            "/pending — новые заказы"
        ),
    },
}


def t(key: str, lang: Optional[str] = "en", **kwargs) -> str:
    lang = (lang or "en").lower()
    if lang not in LOCALES:
        lang = "en"
    value = LOCALES[lang].get(key) or LOCALES["en"].get(key, key)
    if kwargs:
        try:
            value = value.format(**kwargs)
        except Exception:
            pass
    return value
