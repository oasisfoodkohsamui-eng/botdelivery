"""User-facing bot handlers."""
from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from bot.config import settings
from bot.handlers._state import get_lang, resolve_lang, set_lang
from bot.keyboards import language_picker, main_menu, webapp_button
from bot.locales import t

router = Router(name="user")


@router.message(CommandStart())
async def cmd_start(message: Message):
    user = message.from_user
    lang = resolve_lang(user.id, user.language_code)
    set_lang(user.id, lang)
    await message.answer(
        t("welcome", lang),
        reply_markup=main_menu(lang),
        parse_mode="HTML",
    )
    await message.answer(t("open_app", lang) + " ⬇️", reply_markup=webapp_button(lang))


@router.message(Command("menu"))
async def cmd_menu(message: Message):
    lang = get_lang(message.from_user.id)
    await message.answer(t("open_app", lang) + " ⬇️", reply_markup=webapp_button(lang))


@router.message(Command("help"))
async def cmd_help(message: Message):
    lang = get_lang(message.from_user.id)
    await message.answer(t("help", lang), parse_mode="HTML")


@router.message(Command("lang"))
async def cmd_lang(message: Message):
    lang = get_lang(message.from_user.id)
    await message.answer(t("choose_language", lang), reply_markup=language_picker())


@router.callback_query(F.data.startswith("setlang:"))
async def cb_setlang(call: CallbackQuery):
    new_lang = call.data.split(":", 1)[1]
    if new_lang not in ("en", "uk", "ru"):
        await call.answer()
        return
    set_lang(call.from_user.id, new_lang)
    await call.message.edit_text(t("language_set", new_lang))
    await call.message.answer(t("welcome", new_lang), reply_markup=main_menu(new_lang), parse_mode="HTML")
    await call.answer()


# Reply-keyboard buttons
@router.message(F.text.in_({"📦 My orders", "📦 Мої замовлення", "📦 Мои заказы"}))
async def msg_orders(message: Message):
    lang = get_lang(message.from_user.id)
    # Order history lives inside the Mini App
    await message.answer(t("open_app", lang) + " ⬇️", reply_markup=webapp_button(lang))


@router.message(F.text.in_({"🆘 Support", "🆘 Підтримка", "🆘 Поддержка"}))
async def msg_support(message: Message):
    lang = get_lang(message.from_user.id)
    await message.answer(t("support_text", lang, support=f"@{settings.SUPPORT_USERNAME}"))


@router.message(F.text.in_({"🌐 Language", "🌐 Мова", "🌐 Язык"}))
async def msg_language(message: Message):
    lang = get_lang(message.from_user.id)
    await message.answer(t("choose_language", lang), reply_markup=language_picker())
