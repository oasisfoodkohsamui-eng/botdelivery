"""Admin-only handlers."""
import httpx
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from bot.config import settings
from bot.handlers._state import get_lang
from bot.keyboards import order_status_keyboard
from bot.locales import t

router = Router(name="admin")


def _is_admin(user_id: int) -> bool:
    return user_id in settings.admin_id_list


@router.message(Command("admin"))
async def cmd_admin(message: Message):
    lang = get_lang(message.from_user.id)
    if not _is_admin(message.from_user.id):
        await message.answer(t("admin_only", lang))
        return
    await message.answer(t("admin_help", lang), parse_mode="HTML")


@router.message(Command("stats"))
async def cmd_stats(message: Message):
    lang = get_lang(message.from_user.id)
    if not _is_admin(message.from_user.id):
        await message.answer(t("admin_only", lang))
        return
    # We hit our own backend with a service-style call — in production use a service token.
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"{settings.API_BASE_URL}/health")
            health = r.json() if r.status_code == 200 else {}
        await message.answer(
            f"📊 <b>Backend</b>\n"
            f"Status: {health.get('status', '?')}\n"
            f"Version: {health.get('version', '?')}\n"
            f"Env: {health.get('environment', '?')}\n\n"
            f"Open the admin panel for full analytics.",
            parse_mode="HTML",
        )
    except Exception as e:
        await message.answer(f"Backend unreachable: {e}")


@router.message(Command("pending"))
async def cmd_pending(message: Message):
    lang = get_lang(message.from_user.id)
    if not _is_admin(message.from_user.id):
        await message.answer(t("admin_only", lang))
        return
    await message.answer("👉 Open the admin panel to manage pending orders.")


@router.callback_query(F.data.startswith("ord:"))
async def cb_order_status(call: CallbackQuery):
    if not _is_admin(call.from_user.id):
        await call.answer("Admin only", show_alert=True)
        return
    _, order_id, status = call.data.split(":")
    # In production: call backend admin endpoint with a signed service token.
    await call.answer(f"Order {order_id} → {status}", show_alert=False)
    try:
        await call.message.edit_reply_markup(reply_markup=order_status_keyboard(int(order_id)))
    except Exception:
        pass
