"""Per-user language preference store (in-memory + fallback)."""
from typing import Dict, Optional

_user_lang: Dict[int, str] = {}


def set_lang(user_id: int, lang: str) -> None:
    _user_lang[user_id] = lang


def get_lang(user_id: int, default: str = "en") -> str:
    return _user_lang.get(user_id, default)


def resolve_lang(user_id: int, tg_language_code: Optional[str]) -> str:
    """Pick the best language for a user."""
    if user_id in _user_lang:
        return _user_lang[user_id]
    code = (tg_language_code or "en").lower()
    if code.startswith("uk"):
        return "uk"
    if code.startswith("ru"):
        return "ru"
    return "en"
