"""Bot config (loaded from env)."""
from functools import lru_cache
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class BotSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    BOT_TOKEN: str = Field(...)
    ADMIN_IDS: str = Field(default="")
    MINI_APP_URL: str = Field(default="https://your-mini-app.example.com")
    BOT_USERNAME: str = Field(default="OasisFoodSamuiBot")
    API_BASE_URL: str = Field(default="http://backend:8000")
    SUPPORT_USERNAME: str = Field(default="OasisSupport")

    @property
    def admin_id_list(self) -> List[int]:
        if not self.ADMIN_IDS:
            return []
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip()]


@lru_cache
def get_settings() -> BotSettings:
    return BotSettings()


settings = get_settings()
