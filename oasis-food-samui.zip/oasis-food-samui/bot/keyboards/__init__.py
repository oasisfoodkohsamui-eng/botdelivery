"""Inline / reply keyboards for the bot."""
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    WebAppInfo,
)

from bot.config import settings
from bot.locales import t


def main_menu(lang: str) -> ReplyKeyboardMarkup:
    """Persistent bottom keyboard with WebApp launcher."""
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text=t("open_app", lang),
                    web_app=WebAppInfo(url=settings.MINI_APP_URL),
                )
            ],
            [
                KeyboardButton(text=t("orders", lang)),
                KeyboardButton(text=t("support", lang)),
            ],
            [KeyboardButton(text=t("language", lang))],
        ],
        resize_keyboard=True,
    )


def webapp_button(lang: str) -> InlineKeyboardMarkup:
    """Single inline button to launch the Mini App."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=t("open_app", lang),
                    web_app=WebAppInfo(url=settings.MINI_APP_URL),
                )
            ]
        ]
    )


def language_picker() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🇬🇧 English", callback_data="setlang:en"),
                InlineKeyboardButton(text="🇺🇦 Українська", callback_data="setlang:uk"),
                InlineKeyboardButton(text="🇷🇺 Русский", callback_data="setlang:ru"),
            ]
        ]
    )


def order_status_keyboard(order_id: int) -> InlineKeyboardMarkup:
    """Admin keyboard to change order status."""
    statuses = [
        ("✅ Accept", "accepted"),
        ("👨‍🍳 Cooking", "cooking"),
        ("🛵 Delivering", "delivering"),
        ("📦 Delivered", "delivered"),
        ("❌ Cancel", "cancelled"),
    ]
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"ord:{order_id}:{code}")]
        for label, code in statuses
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)
